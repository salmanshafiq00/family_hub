// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Bengali Bangla (`bn`).
class AppLocalizationsBn extends AppLocalizations {
  AppLocalizationsBn([String locale = 'bn']) : super(locale);

  @override
  String get appName => 'ফ্যামিলি হাব';

  @override
  String get navHome => 'হোম';

  @override
  String get navChores => 'কাজ';

  @override
  String get navBazar => 'বাজার';

  @override
  String get navFamily => 'পরিবার';

  @override
  String get actionSave => 'সংরক্ষণ';

  @override
  String get actionCancel => 'বাতিল';

  @override
  String get actionRetry => 'আবার চেষ্টা করুন';

  @override
  String get actionDelete => 'মুছুন';

  @override
  String get actionEdit => 'সম্পাদনা';

  @override
  String get actionAdd => 'যোগ করুন';

  @override
  String get catalogEditorEmpty => 'এখনও কিছু নেই।';

  @override
  String get catalogEditorActions => 'সারির কাজ';

  @override
  String get catalogEditorActivate => 'আবার চালু করুন';

  @override
  String get catalogEditorDeactivate => 'বন্ধ করুন';

  @override
  String get catalogEditorAddTitle => 'নতুন সারি';

  @override
  String get catalogEditorEditTitle => 'সারি সম্পাদনা';

  @override
  String get catalogEditorLabelBn => 'নাম (বাংলা)';

  @override
  String get catalogEditorLabelEn => 'নাম (ইংরেজি, ঐচ্ছিক)';

  @override
  String get actionClose => 'বন্ধ করুন';

  @override
  String get actionBack => 'ফিরে যান';

  @override
  String get actionContinue => 'চালিয়ে যান';

  @override
  String get actionDone => 'সম্পন্ন';

  @override
  String get authSignInTitle => 'লগ ইন করুন';

  @override
  String get authSignUpTitle => 'নতুন অ্যাকাউন্ট খুলুন';

  @override
  String get authEmailLabel => 'ইমেইল';

  @override
  String get authPasswordLabel => 'পাসওয়ার্ড';

  @override
  String get authForgotPassword => 'পাসওয়ার্ড ভুলে গেছেন?';

  @override
  String get authSignOut => 'লগ আউট';

  @override
  String get authEmailVerificationSent => 'যাচাইকরণ ইমেইল পাঠানো হয়েছে।';

  @override
  String get authWelcomeHeadline => 'পরিবারের হিসাব, এক জায়গায়';

  @override
  String get authWelcomeMessage =>
      'বাজার খরচ, পরিবারের তহবিল আর কাজের রুটিন — সবাই মিলে একসাথে সামলান।';

  @override
  String get authGetStarted => 'শুরু করুন';

  @override
  String get authSignInAction => 'লগ ইন';

  @override
  String get authCreateAccountAction => 'নতুন অ্যাকাউন্ট খুলুন';

  @override
  String get authSignInSubtitle =>
      'আপনার ইমেইল ও পাসওয়ার্ড দিয়ে প্রবেশ করুন।';

  @override
  String get authSignUpSubtitle =>
      'অ্যাকাউন্ট খুললে একটি যাচাইকরণ ইমেইল পাঠানো হবে।';

  @override
  String get authNoAccountYet => 'অ্যাকাউন্ট নেই?';

  @override
  String get authAlreadyHaveAccount => 'আগেই অ্যাকাউন্ট আছে?';

  @override
  String get authShowPassword => 'পাসওয়ার্ড দেখান';

  @override
  String get authHidePassword => 'পাসওয়ার্ড লুকান';

  @override
  String get authEmailHint => 'যেমন name@example.com';

  @override
  String get authPasswordHint => 'অন্তত ৮ অক্ষর';

  @override
  String get authEmailConfirmed => 'ইমেইল';

  @override
  String get authPasswordTooShortHelper => 'কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন।';

  @override
  String get authPasswordConfirmLabel => 'পাসওয়ার্ড আবার লিখুন';

  @override
  String get authFailureValidationPasswordMismatch =>
      'দুটি পাসওয়ার্ড মিলছে না।';

  @override
  String get authFailureValidationPasswordConfirmRequired =>
      'পাসওয়ার্ডটি আবার লিখুন।';

  @override
  String get authForgotPasswordTitle => 'পাসওয়ার্ড রিসেট';

  @override
  String get authForgotPasswordSubtitle =>
      'ইমেইল দিন, আমরা একটি রিসেট লিংক পাঠাব।';

  @override
  String get authForgotPasswordSend => 'রিসেট লিংক পাঠান';

  @override
  String get authForgotPasswordSentTitle => 'ইমেইল পাঠানো হয়েছে';

  @override
  String authForgotPasswordSentMessage(String email) {
    return '$email ঠিকানায় একটি রিসেট লিংক পাঠানো হয়েছে। স্প্যাম ফোল্ডারও দেখে নিন।';
  }

  @override
  String get authVerifyEmailTitle => 'ইমেইল যাচাই করুন';

  @override
  String authVerifyEmailMessage(String email) {
    return '$email ঠিকানায় একটি যাচাইকরণ লিংক পাঠানো হয়েছে। লিংকে চাপ দিয়ে তারপর নিচের বাটনে চাপ দিন।';
  }

  @override
  String get authVerifyEmailIHaveVerified => 'আমি যাচাই করেছি';

  @override
  String get authVerifyEmailResend => 'আবার ইমেইল পাঠান';

  @override
  String get authVerifyEmailStillUnverified =>
      'এখনো যাচাই হয়নি। ইমেইলের লিংকে চাপ দিন, তারপর আবার চেষ্টা করুন।';

  @override
  String get authVerifyEmailVerified => 'ইমেইল যাচাই সম্পন্ন হয়েছে।';

  @override
  String get authVerifyEmailSignOutInstead => 'অন্য অ্যাকাউন্টে ঢুকুন';

  @override
  String authUsingAccount(String email) {
    return 'লগ ইন করা আছে: $email';
  }

  @override
  String get authFailurePermissionDenied => 'আপনার এই কাজটি করার অনুমতি নেই।';

  @override
  String get authFailureNotFound => 'আপনার অ্যাকাউন্টটি খুঁজে পাওয়া যায়নি।';

  @override
  String get authFailureConflict =>
      'কেউ ইতিমধ্যে তথ্য বদলেছে। অ্যাপটি আবার খুলে চেষ্টা করুন।';

  @override
  String get authFailureNetwork =>
      'ইন্টারনেট সংযোগ পাওয়া যায়নি। সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।';

  @override
  String get authFailureInvalidCredentials => 'ইমেইল বা পাসওয়ার্ড ঠিক নয়।';

  @override
  String get authFailureUserNotFound => 'এই ইমেইলে কোনো অ্যাকাউন্ট নেই।';

  @override
  String get authFailureEmailInUse =>
      'এই ইমেইলে আগেই একটি অ্যাকাউন্ট আছে। লগ ইন করে দেখুন।';

  @override
  String get authFailureWeakPassword =>
      'পাসওয়ার্ডটি দুর্বল। অন্তত ৮ অক্ষরের পাসওয়ার্ড দিন।';

  @override
  String get authFailureTooManyRequests =>
      'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।';

  @override
  String get authFailureUserDisabled =>
      'এই অ্যাকাউন্টটি বন্ধ করা হয়েছে। পরিবারের অ্যাডমিনের সাথে কথা বলুন।';

  @override
  String get authFailureRequiresRecentLogin =>
      'নিরাপত্তার জন্য আবার লগ ইন করুন, তারপর চেষ্টা করুন।';

  @override
  String get authFailureInvalidEmail => 'ইমেইল ঠিকানাটি সঠিক নয়।';

  @override
  String get authFailureNoCurrentUser =>
      'আপনি আগে লগ আউট করেছেন। আবার লগ ইন করুন।';

  @override
  String authFailureValidationRequired(String field) {
    return '$field পূরণ করুন।';
  }

  @override
  String get authFailureValidationInvalidEmail => 'সঠিক ইমেইল ঠিকানা দিন।';

  @override
  String get authFailureValidationPasswordTooShort =>
      'পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।';

  @override
  String get authFailureUnknown => 'কিছু একটা ভুল হয়েছে। আবার চেষ্টা করুন।';

  @override
  String get authFieldEmail => 'ইমেইল';

  @override
  String get authFieldPassword => 'পাসওয়ার্ড';

  @override
  String get errorPermissionDenied => 'আপনার এই কাজটি করার অনুমতি নেই।';

  @override
  String get errorNotFound => 'তথ্যটি খুঁজে পাওয়া যায়নি।';

  @override
  String get errorConflict =>
      'কেউ ইতিমধ্যে এই তথ্য পরিবর্তন করেছে। আবার চেষ্টা করুন।';

  @override
  String get errorNetwork =>
      'ইন্টারনেট সংযোগ পাওয়া যায়নি। সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।';

  @override
  String get errorUnknown => 'কিছু একটা ভুল হয়েছে। আবার চেষ্টা করুন।';

  @override
  String errorValidationRequired(String field) {
    return '$field পূরণ করুন।';
  }

  @override
  String get errorValidationEmail => 'সঠিক ইমেইল ঠিকানা দিন।';

  @override
  String get errorValidationPasswordTooShort =>
      'পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।';

  @override
  String get emptyGenericTitle => 'এখনো কিছু নেই';

  @override
  String get emptyGenericMessage => 'শুরু করতে নিচের বাটনে চাপ দিন।';

  @override
  String get emptyNoDataTitle => 'কোনো তথ্য নেই';

  @override
  String get emptyNoDataMessage => 'এই তালিকাটি এখন খালি।';

  @override
  String get loadingGeneric => 'লোড হচ্ছে…';

  @override
  String get offlineBanner => 'আপনি অফলাইনে আছেন। সংযোগ ফিরলে তথ্য সিঙ্ক হবে।';

  @override
  String get settingsTitle => 'সেটিংস';

  @override
  String get settingsThemeTitle => 'অ্যাপিয়ারেন্স';

  @override
  String get settingsThemeMode => 'থিম মোড';

  @override
  String get settingsColourPalette => 'রঙের প্যালেট';

  @override
  String get settingsFollowDevice => 'ডিভাইস অনুসরণ করুন';

  @override
  String get settingsFollowDeviceSubtitle =>
      'আপনার সিস্টেমের আলো / অন্ধকার সেটিং ব্যবহার করবে';

  @override
  String get settingsThemeSelected => 'নির্বাচিত';

  @override
  String settingsThemeSelectedSemantics(String theme) {
    return '$theme থিম, নির্বাচিত';
  }

  @override
  String settingsThemeUnselectedSemantics(String theme) {
    return '$theme থিম';
  }

  @override
  String get settingsLanguageTitle => 'ভাষা';

  @override
  String get settingsLanguageSection => 'ভাষা নির্বাচন করুন';

  @override
  String get settingsLanguageBangla => 'বাংলা';

  @override
  String get settingsLanguageEnglish => 'ইংরেজি';

  @override
  String get settingsLanguageSubtitle =>
      'অ্যাপের ভাষা তাৎক্ষণিকভাবে পরিবর্তিত হয়';

  @override
  String get settingsBanglaDigits => 'বাংলা অঙ্ক ব্যবহার করুন';

  @override
  String get settingsBanglaDigitsSubtitle =>
      'সংখ্যা ও তারিখ বাংলা অঙ্কে (০১২৩) দেখাবে';

  @override
  String settingsLanguageSelectedSemantics(String language) {
    return '$language ভাষা, নির্বাচিত';
  }

  @override
  String get languageNameBn => 'বাংলা';

  @override
  String get languageNameEn => 'English';

  @override
  String get devTokensTitle => 'ডেভ — থিম টোকেন';

  @override
  String get devGalleryTitle => 'ডেভ — গ্যালারি';

  @override
  String get homeViewThemeTokens => 'থিম টোকেন দেখুন';

  @override
  String get moduleComingSoonTitle => 'শীঘ্রই আসছে';

  @override
  String get moduleComingSoonMessage => 'এই অংশটি এখনো তৈরি হচ্ছে।';

  @override
  String get bazarHomeEmptyTitle => 'বাজার এখনো খালি';

  @override
  String get bazarHomeEmptyMessage =>
      'খরচ, বাজার তালিকা ও হিসাবের অংশগুলো ধাপে ধাপে এখানে যোগ হবে।';

  @override
  String get bazarCatalogSetupTitle => 'স্টার্টার বাজার তালিকা সেট করুন';

  @override
  String get bazarCatalogSetupMessage =>
      'শুরু করার জন্য ১১টি ক্যাটাগরি ও ৫৪টি সাধারণ আইটেম যোগ করুন। পরে আপনি সেগুলো সম্পাদনা, যোগ বা লুকাতে পারবেন।';

  @override
  String get bazarCatalogSetupAction => 'তালিকা তৈরি করুন';

  @override
  String get bazarCatalogSetupBusy => 'বাজার তালিকা তৈরি হচ্ছে…';

  @override
  String get bazarCatalogAskAdminTitle => 'বাজার তালিকা তৈরি হয়নি';

  @override
  String get bazarCatalogAskAdminMessage =>
      'বাজার তালিকা তৈরি করতে একজন অ্যাডমিনকে বলুন।';

  @override
  String get bazarSettingsTitle => 'বাজারের সেটিংস';

  @override
  String get unitKg => 'কেজি';

  @override
  String get unitG => 'গ্রাম';

  @override
  String get unitLitre => 'লিটার';

  @override
  String get unitPiece => 'পিস';

  @override
  String get unitDozen => 'ডজন';

  @override
  String get unitPacket => 'প্যাকেট';

  @override
  String get unitCylinder => 'সিলিন্ডার';

  @override
  String get bazarFundingFund => 'পরিবারের তহবিল';

  @override
  String get bazarFundingMember => 'সদস্য পরিশোধিত';

  @override
  String get bazarAdvancePending => 'অপেক্ষমাণ';

  @override
  String get bazarAdvancePartial => 'আংশিক সমন্বিত';

  @override
  String get bazarAdvanceSettled => 'সমন্বিত';

  @override
  String get bazarAdvanceVoided => 'বাতিল';

  @override
  String get bazarErrRequired => 'এই ঘরটি পূরণ করুন।';

  @override
  String get bazarErrTooLong => 'লেখাটি অনেক বড় হয়ে গেছে।';

  @override
  String get bazarErrInvalidAmount => 'সঠিক অঙ্ক লিখুন।';

  @override
  String get bazarErrAmountNotPositive => 'অঙ্কটি শূন্যের বেশি হতে হবে।';

  @override
  String get bazarErrFutureDate => 'তারিখ ভবিষ্যতের হতে পারে না।';

  @override
  String get bazarErrQtyUnitRequired => 'পরিমাণ ও একক দুটোই দিন।';

  @override
  String get bazarErrMemberRequired => 'সদস্যটি বেছে নিন।';

  @override
  String get bazarErrCategoryRequired => 'ক্যাটাগরি বেছে নিন।';

  @override
  String get bazarErrItemNameRequired => 'আইটেমের নাম লিখুন।';

  @override
  String get bazarErrTooManyLines => 'সারি অনেক বেশি; কিছু সরিয়ে দিন।';

  @override
  String get bazarErrInvalidMonth => 'সঠিক মাস বেছে নিন।';

  @override
  String get bazarErrInvalidRange => 'শেষ তারিখ শুরুর তারিখের পরে হতে হবে।';

  @override
  String get bazarErrNegative => 'অঙ্ক ঋণাত্মক হতে পারে না।';

  @override
  String get bazarErrTooManyDecimals =>
      'সর্বোচ্চ দুই দশমিক স্থান ব্যবহার করুন।';

  @override
  String get bazarErrTooLarge => 'অঙ্কটি অনেক বড়।';

  @override
  String get bazarErrMonthLocked => 'এই মাস বন্ধ আছে। খুলতে অ্যাডমিনকে বলুন।';

  @override
  String get bazarErrAdvanceSettled =>
      'এই অগ্রিম আংশিক বা সম্পূর্ণ সমন্বয় হয়ে গেছে।';

  @override
  String get bazarErrOverpayment =>
      'বাকি থাকা অঙ্কের চেয়ে বেশি দেওয়া হয়েছে।';

  @override
  String get bazarErrAlreadyClosed => 'এই মাস ইতিমধ্যে বন্ধ আছে।';

  @override
  String get bazarErrNotClosed => 'এই মাস বন্ধ নয়।';

  @override
  String get bazarErrReopenNoteRequired => 'মাসটি কেন খুলছেন তা লিখুন।';

  @override
  String get bazarErrCatalogNotEmpty =>
      'তালিকায় এখনো আইটেম আছে; আগে সেগুলো আর্কাইভ করুন।';

  @override
  String get bazarErrDuplicateItem =>
      'ঠিক এই ধরনের খরচ সবেমাত্র যোগ হয়েছে। আবার সংরক্ষণের আগে দেখে নিন।';

  @override
  String get bazarErrImportAlreadyUndone => 'এই ইমপোর্ট আগেই বাতিল হয়েছে।';

  @override
  String get bazarErrImportHasLockedMonth => 'ফাইলে বন্ধ মাসের সারি আছে।';

  @override
  String get bazarErrConcurrentEdit =>
      'আপনার আগেই কেউ এটি বদলেছেন। রিফ্রেশ করে আবার চেষ্টা করুন।';

  @override
  String get bazarErrNotFound =>
      'রেকর্ডটি আর নেই। রিফ্রেশ করে আবার চেষ্টা করুন।';

  @override
  String get bazarErrNotAllowed =>
      'শুধু সংসার ব্যবস্থাপক বা অ্যাডমিন এটি করতে পারেন।';

  @override
  String get bazarErrUnknown => 'কিছু একটা সমস্যা হয়েছে। আবার চেষ্টা করুন।';

  @override
  String get profileSetupTitle => 'আপনার প্রোফাইল তৈরি করুন';

  @override
  String get profileSetupMessage => 'পরিবারকে জানান আপনি কে।';

  @override
  String get familyChoiceTitle => 'পরিবারে যোগ দিন বা নতুন তৈরি করুন';

  @override
  String get familyChoiceMessage =>
      'নতুন পরিবার তৈরি করুন, অথবা আমন্ত্রণ কোড দিয়ে যোগ দিন।';

  @override
  String get pendingTitle => 'অনুমোদনের অপেক্ষায়';

  @override
  String get pendingMessage =>
      'চালিয়ে যেতে পরিবারের অ্যাডমিনকে আপনার অনুরোধ অনুমোদন করতে হবে।';

  @override
  String get disabledTitle => 'প্রবেশ বন্ধ আছে';

  @override
  String get disabledMessage =>
      'এই পরিবারে আপনার প্রবেশ বন্ধ করা হয়েছে। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।';

  @override
  String get placeholderContinueProfile => 'চালিয়ে যান (অস্থায়ী)';

  @override
  String get placeholderCreateFamily =>
      'পরীক্ষামূলক পরিবার তৈরি করুন (অস্থায়ী)';

  @override
  String get placeholderApproveMe => 'অনুমোদিত ধরে নিন (অস্থায়ী)';

  @override
  String get notFoundTitle => 'পাতাটি পাওয়া যায়নি';

  @override
  String get notFoundMessage => 'আপনি যে পাতাটি খুলেছেন সেটি নেই।';

  @override
  String get notFoundAction => 'হোমে যান';

  @override
  String get profileFullName => 'পুরো নাম';

  @override
  String get profileNickname => 'ডাকনাম (ঐচ্ছিক)';

  @override
  String get profileGender => 'লিঙ্গ (ঐচ্ছিক)';

  @override
  String get genderMale => 'পুরুষ';

  @override
  String get genderFemale => 'নারী';

  @override
  String get genderOther => 'অন্যান্য';

  @override
  String get genderNone => 'বলতে চাই না';

  @override
  String get profileRelationship => 'সম্পর্ক';

  @override
  String get profileAvatar => 'একটি অ্যাভাটার বেছে নিন';

  @override
  String get profileSave => 'প্রোফাইল সংরক্ষণ করুন';

  @override
  String get profileSpouse => 'স্বামী/স্ত্রী (ঐচ্ছিক)';

  @override
  String get profileSpouseNone => 'কেউ নয়';

  @override
  String get relFather => 'বাবা';

  @override
  String get relMother => 'মা';

  @override
  String get relSon => 'ছেলে';

  @override
  String get relDaughter => 'মেয়ে';

  @override
  String get relHusband => 'স্বামী';

  @override
  String get relWife => 'স্ত্রী';

  @override
  String get relHousewife => 'গৃহিণী';

  @override
  String get relDaughterInLaw => 'পুত্রবধূ';

  @override
  String get relSonInLaw => 'জামাই';

  @override
  String get relOther => 'অন্যান্য';

  @override
  String get familyCreateAction => 'নতুন পরিবার তৈরি করুন';

  @override
  String get familyJoinAction => 'কোড দিয়ে যোগ দিন';

  @override
  String get familyNameLabel => 'পরিবারের নাম';

  @override
  String get familyCreateSubmit => 'পরিবার তৈরি করুন';

  @override
  String get joinCodeLabel => 'আমন্ত্রণ কোড';

  @override
  String get joinSubmit => 'যোগদানের অনুরোধ করুন';

  @override
  String get joinHint => 'পরিবারের অ্যাডমিনের কাছ থেকে ৮ অক্ষরের কোড নিন।';

  @override
  String get membersTitle => 'সদস্য';

  @override
  String get membersPending => 'অনুমোদনের অপেক্ষায়';

  @override
  String get membersActive => 'সক্রিয়';

  @override
  String get membersDisabled => 'নিষ্ক্রিয়';

  @override
  String get memberYou => 'আপনি';

  @override
  String get memberApprove => 'অনুমোদন';

  @override
  String get memberReject => 'প্রত্যাখ্যান';

  @override
  String get memberDisable => 'নিষ্ক্রিয় করুন';

  @override
  String get memberReenable => 'আবার সক্রিয় করুন';

  @override
  String get roleAdmin => 'অ্যাডমিন';

  @override
  String get roleModerator => 'সংসার ব্যবস্থাপক';

  @override
  String get roleMember => 'সদস্য';

  @override
  String get memberProfileTitle => 'সদস্যের প্রোফাইল';

  @override
  String get memberEditProfile => 'আমার প্রোফাইল সম্পাদনা';

  @override
  String get memberRoleLabel => 'ভূমিকা';

  @override
  String get memberStatusLabel => 'অবস্থা';

  @override
  String get invitationsTitle => 'আমন্ত্রণ';

  @override
  String get invitationCreate => 'আমন্ত্রণ কোড তৈরি করুন';

  @override
  String get invitationCopy => 'কোড কপি করুন';

  @override
  String get invitationCopied => 'কোড কপি হয়েছে';

  @override
  String get invitationExpiresOn => 'মেয়াদ শেষ';

  @override
  String get invStatusActive => 'অব্যবহৃত';

  @override
  String get invStatusUsed => 'ব্যবহৃত';

  @override
  String get invStatusExpired => 'মেয়াদোত্তীর্ণ';

  @override
  String get invStatusRevoked => 'বাতিল';

  @override
  String get invitationsEmpty => 'এখনো কোনো আমন্ত্রণ নেই';

  @override
  String get rolesTitle => 'ভূমিকা';

  @override
  String get rolesMakeAdmin => 'অ্যাডমিন বানান';

  @override
  String get rolesTransferTitle => 'অ্যাডমিনের দায়িত্ব হস্তান্তর করবেন?';

  @override
  String get rolesTransferMessage => 'আপনি সাধারণ সদস্য হয়ে যাবেন।';

  @override
  String get actionConfirm => 'নিশ্চিত করুন';

  @override
  String get familySettingsTitle => 'পরিবারের সেটিংস';

  @override
  String get settingsTimezone => 'সময় অঞ্চল';

  @override
  String get settingsCurrency => 'মুদ্রা';

  @override
  String get settingsModules => 'মডিউল';

  @override
  String get settingsSaved => 'সংরক্ষিত হয়েছে';

  @override
  String get famFailureNameRequired => 'একটি নাম লিখুন।';

  @override
  String get famFailureCodeInvalid =>
      'কোডটি সঠিক নয়। কোডে ৮টি অক্ষর ও সংখ্যা থাকে।';

  @override
  String get famFailureCodeNotFound => 'এই কোডে কোনো আমন্ত্রণ পাওয়া যায়নি।';

  @override
  String get famFailureCodeUsed => 'এই কোডটি আগেই ব্যবহার করা হয়েছে।';

  @override
  String get famFailureCodeExpired => 'কোডটির মেয়াদ শেষ। নতুন কোড চান।';

  @override
  String get famFailureCodeRevoked => 'কোডটি বাতিল করা হয়েছে।';

  @override
  String get famFailureAlreadyMember => 'আপনি ইতিমধ্যে এই পরিবারে আছেন।';

  @override
  String get famFailureLastAdmin =>
      'পরিবারে অন্তত একজন অ্যাডমিন থাকতে হবে। আগে অন্য কাউকে অ্যাডমিন বানান।';

  @override
  String get famFailureTooManyAdmins =>
      'একটি পরিবারে সর্বোচ্চ তিনজন অ্যাডমিন থাকতে পারে।';

  @override
  String get famFailureNotAllowed => 'এটি করার অনুমতি আপনার নেই।';

  @override
  String get famFailureProfileRequired => 'আগে আপনার প্রোফাইল সম্পূর্ণ করুন।';

  @override
  String avatarOption(String number) {
    return 'অ্যাভাটার $number';
  }

  @override
  String get statusScheduled => 'সময় নির্ধারিত';

  @override
  String get statusInProgress => 'চলছে';

  @override
  String get statusCompleted => 'সম্পন্ন';

  @override
  String get statusVerified => 'যাচাইকৃত';

  @override
  String get statusOverdue => 'সময় পার হয়েছে';

  @override
  String get commonSeeAll => 'সব দেখুন';

  @override
  String get errorViewTitle => 'কিছু ভুল হয়েছে';

  @override
  String get loadingSemantics => 'লোড হচ্ছে';

  @override
  String progressSemantics(String label, String percent) {
    return '$label, $percent শতাংশ সম্পন্ন';
  }

  @override
  String thumbSemantics(String name) {
    return '$name ছবি';
  }

  @override
  String get galleryAvatar => 'অ্যাভাটার';

  @override
  String get galleryItemThumb => 'জিনিসের ছবি';

  @override
  String get galleryStatusChip => 'অবস্থার চিপ';

  @override
  String get galleryStatusGlyph => 'অবস্থার চিহ্ন';

  @override
  String get galleryFlagChip => 'ফ্ল্যাগ চিপ';

  @override
  String get galleryReasonSheet => 'কারণ শিট';

  @override
  String get galleryMinutesField => 'সময়ের ঘর';

  @override
  String get galleryWeekdayChips => 'বার বাছাই';

  @override
  String get galleryColorSwatchPicker => 'রং বাছাই';

  @override
  String get galleryAvatarStack => 'অ্যাভাটার সারি';

  @override
  String get galleryStepProgress => 'ধাপের অগ্রগতি';

  @override
  String get galleryMiniMarkdown => 'ঘরের নিয়মের লেখা';

  @override
  String get galleryCatalogEditor => 'তালিকা সম্পাদনা';

  @override
  String get galleryOpenSheet => 'শিট খুলুন';

  @override
  String get gallerySampleDueTime => 'শেষ সময়';

  @override
  String get gallerySampleRules =>
      '# ঘরের নিয়ম\n- খাওয়ার পর নিজের প্লেট ধুয়ে রাখা\n- **সকাল ৯টার মধ্যে রান্নাঘর খালি থাকতে হবে**\n1. গাছে পানি দেওয়া\n2. উঠান ঝাঁট দেওয়া';

  @override
  String get gallerySectionHeader => 'সেকশন হেডার';

  @override
  String get galleryAppCard => 'কার্ড';

  @override
  String get galleryMoneyText => 'টাকার লেখা';

  @override
  String get galleryProgressRing => 'প্রগ্রেস রিং';

  @override
  String get galleryEmptyState => 'খালি অবস্থা';

  @override
  String get galleryLoadingView => 'লোডিং দৃশ্য';

  @override
  String get galleryErrorView => 'ত্রুটির দৃশ্য';

  @override
  String get galleryPillBottomBar => 'পিল নেভিগেশন বার';

  @override
  String get gallerySampleTitle => 'নমুনা শিরোনাম';

  @override
  String get gallerySampleMessage =>
      'এটি একটি নমুনা বার্তা যা ওভারফ্লো যাচাই করে।';

  @override
  String get gallerySampleItemName => 'আলু';

  @override
  String get gallerySamplePersonName => 'করিম উদ্দিন';

  @override
  String get syncWaitingTitle => 'সংযোগের অপেক্ষায়…';

  @override
  String get syncWaitingMessage =>
      'ইন্টারনেট সংযোগ আছে কিনা দেখুন, তারপর আবার চেষ্টা করুন। আপনার তথ্য নিরাপদ আছে।';

  @override
  String get syncSavedOffline =>
      'এই ডিভাইসে সংরক্ষিত হয়েছে — অনলাইনে এলে সিঙ্ক হবে';

  @override
  String syncBannerSyncing(int count) {
    return '$countটি পরিবর্তন সিঙ্ক হচ্ছে';
  }

  @override
  String syncBannerOffline(int count) {
    return 'অফলাইন — $countটি পরিবর্তন অপেক্ষায়';
  }

  @override
  String get gallerySyncBanner => 'সিঙ্ক ব্যানার';

  @override
  String get galleryReorderMoveButtons => 'উপরে / নিচে সরান';

  @override
  String get famFailureAlreadyInFamily =>
      'আপনি ইতিমধ্যে একটি পরিবারে আছেন। আগে সেটি ছেড়ে দিন।';

  @override
  String get familyLeave => 'পরিবার ছেড়ে যান';

  @override
  String get familyLeaveConfirmTitle => 'পরিবার ছেড়ে যাবেন?';

  @override
  String get familyLeaveConfirmBody =>
      'আপনার আগের কাজ ও হিসাবের ইতিহাস পরিবারে থেকে যাবে। পরে আপনি নতুন পরিবার খুলতে বা অন্য পরিবারে যোগ দিতে পারবেন।';

  @override
  String get familyLeaveLastAdminReason =>
      'আপনিই একমাত্র অ্যাডমিন। ছেড়ে যাওয়ার আগে আরেকজনকে অ্যাডমিন করুন।';

  @override
  String get pendingCancelRequest => 'অনুরোধ বাতিল করুন';

  @override
  String get invitationRevoke => 'কোড বাতিল করুন';

  @override
  String get invitationRevokeConfirmTitle => 'কোডটি বাতিল করবেন?';

  @override
  String get invitationRevokeConfirmBody =>
      'এই কোড দিয়ে আর কেউ যোগ দিতে পারবে না।';

  @override
  String get securityTitle => 'নিরাপত্তা';

  @override
  String get securityChangePassword => 'পাসওয়ার্ড পরিবর্তন';

  @override
  String get securityCurrentPassword => 'বর্তমান পাসওয়ার্ড';

  @override
  String get securityNewPassword => 'নতুন পাসওয়ার্ড';

  @override
  String get securityPasswordChanged => 'পাসওয়ার্ড পরিবর্তন হয়েছে।';

  @override
  String get securityPasswordSame =>
      'নতুন পাসওয়ার্ড বর্তমানটির থেকে আলাদা হতে হবে।';

  @override
  String get securityCurrentPasswordRequired =>
      'আপনার বর্তমান পাসওয়ার্ড লিখুন।';

  @override
  String get securityCurrentPasswordWrong => 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।';

  @override
  String get securityDeleteTitle => 'আমার অ্যাকাউন্ট মুছুন';

  @override
  String get securityDeleteBody =>
      'আপনি পরিবার ছেড়ে যাবেন এবং আপনার সাইন-ইন মুছে যাবে। পরিবারের ইতিহাস ঠিক রাখতে পুরোনো রেকর্ডে আপনার নাম থাকবে।';

  @override
  String get securityDeletePending =>
      'মুছে ফেলা শেষ হয়নি। শেষ করতে পাসওয়ার্ড লিখুন।';

  @override
  String get securityDeleteAction => 'অ্যাকাউন্ট মুছুন';

  @override
  String get securityDeleteFinish => 'মুছে ফেলা শেষ করুন';

  @override
  String get securityDeleteConfirmTitle => 'আপনার অ্যাকাউন্ট মুছবেন?';

  @override
  String get securityDeleteConfirmBody => 'এটি আর ফেরানো যাবে না।';

  @override
  String get accountDeleteLastAdminHasMembers =>
      'আপনি একমাত্র অ্যাডমিন এবং পরিবারে আরও সদস্য আছেন। আগে অ্যাডমিনের দায়িত্ব হস্তান্তর করুন।';

  @override
  String get relationshipsTitle => 'সম্পর্কের তালিকা';

  @override
  String get relationshipsHint =>
      'তৈরি-করা সম্পর্কগুলো পরিবর্তন করা যায় না। নিজের সম্পর্ক যোগ, নাম পরিবর্তন বা বন্ধ করতে পারেন।';

  @override
  String get relationshipsAdd => 'সম্পর্ক যোগ করুন';

  @override
  String get relationshipsLabelBn => 'বাংলায় নাম';

  @override
  String get relationshipsLabelEn => 'ইংরেজিতে নাম';

  @override
  String get relationshipsSpouseRelevant => 'স্বামী/স্ত্রী বাছাই দেখান';

  @override
  String get relationshipsBuiltIn => 'তৈরি-করা';

  @override
  String get relationshipsActive => 'চালু';

  @override
  String get relationshipsDisabled => 'বন্ধ';

  @override
  String get relationshipsEnable => 'চালু করুন';

  @override
  String get relationshipsDisable => 'বন্ধ করুন';

  @override
  String get relationshipsFailureLabel => 'একটি নাম লিখুন (সর্বোচ্চ ৪০ অক্ষর)।';

  @override
  String get relationshipsFailureTooMany => 'তালিকা পূর্ণ।';

  @override
  String get relationshipsFailureBuiltIn =>
      'তৈরি-করা সম্পর্ক পরিবর্তন করা যায় না।';

  @override
  String activityFamilyCreated(String familyName) {
    return 'পরিবার “$familyName” তৈরি হয়েছে';
  }

  @override
  String get activityFamilyUpdated => 'পরিবারের সেটিংস হালনাগাদ হয়েছে';

  @override
  String activityMemberRequested(String memberName) {
    return '$memberName যোগ দিতে অনুরোধ করেছেন';
  }

  @override
  String activityMemberApproved(String memberName) {
    return '$memberName-কে অনুমোদন দেওয়া হয়েছে';
  }

  @override
  String activityMemberRejected(String memberName) {
    return '$memberName-কে গ্রহণ করা হয়নি';
  }

  @override
  String activityMemberDisabled(String memberName) {
    return '$memberName-কে বন্ধ করা হয়েছে';
  }

  @override
  String activityMemberRoleChanged(String memberName, String newRole) {
    return '$memberName এখন $newRole';
  }

  @override
  String activityAdminTransferred(String memberName) {
    return 'অ্যাডমিনের দায়িত্ব $memberName-কে দেওয়া হয়েছে';
  }

  @override
  String activityMemberLeft(String memberName) {
    return '$memberName পরিবার ছেড়ে গেছেন';
  }

  @override
  String activityMemberCancelled(String memberName) {
    return '$memberName অনুরোধ প্রত্যাহার করেছেন';
  }

  @override
  String activityInvitationCreated(String code) {
    return 'আমন্ত্রণ $code তৈরি হয়েছে';
  }

  @override
  String activityInvitationRevoked(String code) {
    return 'আমন্ত্রণ $code বাতিল হয়েছে';
  }

  @override
  String activityBazarCatalogSeeded(String categories, String items) {
    return '$categoriesটি ক্যাটাগরি ও $itemsটি আইটেম দিয়ে বাজারের তালিকা চালু হয়েছে';
  }

  @override
  String activityBazarCategoryCreated(String name) {
    return 'ক্যাটাগরি “$name” যোগ করা হয়েছে';
  }

  @override
  String activityBazarCategoryUpdated(String name) {
    return 'ক্যাটাগরি “$name” হালনাগাদ হয়েছে';
  }

  @override
  String activityBazarCategoryDeactivated(String name) {
    return 'ক্যাটাগরি “$name” আর্কাইভ করা হয়েছে';
  }

  @override
  String activityBazarItemCreated(String name) {
    return 'আইটেম “$name” যোগ করা হয়েছে';
  }

  @override
  String activityBazarItemUpdated(String name) {
    return 'আইটেম “$name” হালনাগাদ হয়েছে';
  }

  @override
  String activityBazarItemDeactivated(String name) {
    return 'আইটেম “$name” আর্কাইভ করা হয়েছে';
  }

  @override
  String activityBazarExpenseCreated(
    String item,
    String amount,
    String funding,
  ) {
    return '$item কেনা হয়েছে $amount দিয়ে ($funding)';
  }

  @override
  String activityBazarExpenseUpdated(String item, String fields) {
    return '$item সম্পাদনা করা হয়েছে ($fields)';
  }

  @override
  String activityBazarExpenseDeleted(String item, String amount) {
    return '$item মুছে ফেলা হয়েছে ($amount)';
  }

  @override
  String activityBazarExpenseRestored(String item, String amount) {
    return '$item ফিরিয়ে আনা হয়েছে ($amount)';
  }

  @override
  String activityBazarTripCreated(String lines, String amount) {
    return '$linesটি আইটেমের বাজার যাত্রা $amount দিয়ে সংরক্ষণ হয়েছে';
  }

  @override
  String activityBazarBudgetSaved(String month, String amount) {
    return '$month-এর বাজেট $amount নির্ধারণ করা হয়েছে';
  }

  @override
  String get activityBazarSettingsUpdated => 'বাজারের সেটিংস হালনাগাদ হয়েছে';

  @override
  String activityBazarContributionPlanSet(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এ $member-এর চাঁদা $amount নির্ধারণ করা হয়েছে';
  }

  @override
  String activityBazarContributionRecorded(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এ $member-এর $amount চাঁদা রেকর্ড করা হয়েছে';
  }

  @override
  String activityBazarContributionVoided(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এ $member-এর $amount চাঁদা বাতিল করা হয়েছে';
  }

  @override
  String activityBazarContributionRequested(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এর জন্য $member $amount দিতে চেয়েছেন';
  }

  @override
  String activityBazarContributionRequestEdited(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এর জন্য $member $amount দেওয়ার অনুরোধ সম্পাদনা করেছেন';
  }

  @override
  String activityBazarContributionRequestCancelled(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এর জন্য $member $amount দেওয়ার অনুরোধ প্রত্যাহার করেছেন';
  }

  @override
  String activityBazarContributionApproved(
    String month,
    String member,
    String amount,
  ) {
    return '$month-এ $member-এর $amount চাঁদা অনুমোদিত হয়েছে';
  }

  @override
  String activityBazarContributionRejected(
    String month,
    String member,
    String amount,
    String reason,
  ) {
    return '$month-এ $member-এর $amount চাঁদা গ্রহণ করা হয়নি ($reason)';
  }

  @override
  String activityBazarContributionChangeRequested(
    String month,
    String member,
    String amount,
    String old,
  ) {
    return '$month-এর জন্য $member $old থেকে $amount-এ চাঁদা বদলাতে বলেছেন';
  }

  @override
  String activityBazarContributionChangeApproved(
    String month,
    String member,
    String amount,
    String old,
  ) {
    return '$month-এ $member-এর চাঁদা $old থেকে $amount-এ বদলের অনুমোদন হয়েছে';
  }

  @override
  String activityBazarContributionChangeRejected(
    String month,
    String member,
    String amount,
    String old,
  ) {
    return '$month-এ $member-এর চাঁদা $old থেকে $amount-এ বদলের অনুমোদন হয়নি';
  }

  @override
  String activityBazarOpeningBalanceSet(String month, String amount) {
    return '$month-এর প্রারম্ভিক ব্যালেন্স $amount';
  }

  @override
  String activityBazarAdvanceSettled(
    String member,
    String amount,
    String status,
  ) {
    return '$member-এর অগ্রিম $amount সমন্বয় হয়েছে ($status)';
  }

  @override
  String activityBazarMonthClosed(String month, String balance) {
    return '$month বন্ধ করা হয়েছে, ব্যালেন্স $balance';
  }

  @override
  String activityBazarMonthReopened(String month, String note) {
    return '$month আবার খোলা হয়েছে ($note)';
  }

  @override
  String activityBazarImportCompleted(String rows, String amount) {
    return 'ইমপোর্ট শেষ: $rowsটি সারি, $amount';
  }

  @override
  String activityBazarImportUndone(String rows, String amount) {
    return 'ইমপোর্ট বাতিল: $rowsটি সারি, $amount';
  }

  @override
  String get activityUnknown => 'কিছু পরিবর্তন হয়েছে';

  @override
  String get galleryMonthSwitcher => 'মাস পরিবর্তনকারী';

  @override
  String get galleryAmountField => 'পরিমাণের ঘর';

  @override
  String get galleryTotalDisplay => 'মোট প্রদর্শন';

  @override
  String get galleryProgressBarStatus => 'সীমার অগ্রগতি বার';

  @override
  String get galleryDaySectionHeader => 'দিনের শিরোনাম';

  @override
  String get galleryPersonPicker => 'ব্যক্তি নির্বাচন';

  @override
  String get galleryCategoryBadge => 'ক্যাটেগরি ব্যাজ';

  @override
  String get monthSwitcherPrevious => 'আগের মাস';

  @override
  String get monthSwitcherNext => 'পরের মাস';

  @override
  String get monthSwitcherPick => 'মাস বেছে নিন';

  @override
  String get monthPickerPreviousYear => 'আগের বছর';

  @override
  String get monthPickerNextYear => 'পরের বছর';

  @override
  String get totalDisplayCalculated => 'পরিমাণ × দর থেকে হিসাব করা';

  @override
  String get totalDisplayEmpty => 'মোট এখনো নেই';

  @override
  String get progressLevelOk => 'ঠিক আছে';

  @override
  String get progressLevelWarning => 'সীমার কাছাকাছি';

  @override
  String get progressLevelExceeded => 'সীমা ছাড়িয়েছে';

  @override
  String get progressLevelNoLimit => 'সীমা নির্ধারিত নেই';

  @override
  String progressBarSemantics(String label, String percent, String level) {
    return '$label: $percent শতাংশ, $level';
  }

  @override
  String get personPickerNone => 'কেউ নয়';

  @override
  String get actionUndo => 'পূর্বাবস্থায় ফেরান';

  @override
  String get bazarErrExpenseDeleted =>
      'এই খরচটি মুছে ফেলা হয়েছে। আগে ফিরিয়ে আনুন।';

  @override
  String get expenseAddTitle => 'খরচ যোগ করুন';

  @override
  String get expenseEditTitle => 'খরচ সম্পাদনা';

  @override
  String get expenseMenuTrip => 'বাজার ট্রিপ (অনেক পণ্য)';

  @override
  String get expenseDateLabel => 'তারিখ';

  @override
  String get expenseItemLabel => 'পণ্য';

  @override
  String get expenseItemHint => 'পণ্যের নাম লিখুন';

  @override
  String expenseAddNewItem(String name) {
    return '$name নতুন পণ্য হিসেবে যোগ করুন';
  }

  @override
  String get expenseCategoryLabel => 'ক্যাটেগরি';

  @override
  String get expenseRememberItem => 'পণ্যটি মনে রাখুন';

  @override
  String get expenseTotalField => 'মোট টাকা';

  @override
  String get expenseTotalLabel => 'মোট';

  @override
  String get expenseQtyPriceSection => 'অথবা পরিমাণ ও প্রতি এককের দাম লিখুন';

  @override
  String get expenseQtyField => 'পরিমাণ';

  @override
  String get expenseUnitLabel => 'একক';

  @override
  String get expenseUnitPriceField => 'প্রতি এককের দাম';

  @override
  String expenseUnitPriceHint(String price) {
    return 'সর্বশেষ দাম: $price';
  }

  @override
  String get expenseFundingLabel => 'কে টাকা দিয়েছে?';

  @override
  String get expenseFundingFund => 'পরিবারের তহবিল থেকে';

  @override
  String get expenseFundingReimbursable => 'সদস্য দিয়েছে, ফেরত পাবে';

  @override
  String get expenseFundingPersonal => 'সদস্য নিজের টাকায় দিয়েছে, ফেরত নয়';

  @override
  String get expensePaidByLabel => 'যিনি দিয়েছেন';

  @override
  String get expenseMoreSection => 'আরও তথ্য';

  @override
  String get expenseShopField => 'দোকান';

  @override
  String get expenseNoteField => 'নোট';

  @override
  String get expensePurchaserLabel => 'যিনি কিনেছেন';

  @override
  String get expenseSaveAddAnother => 'সংরক্ষণ করে আরেকটি যোগ করুন';

  @override
  String get expenseSaved => 'খরচ সংরক্ষণ হয়েছে';

  @override
  String get expenseUpdated => 'খরচ হালনাগাদ হয়েছে';

  @override
  String get expenseUnknownMember => 'একজন সদস্য';

  @override
  String get expenseDuplicateTitle => 'মনে হচ্ছে একই খরচ আগেই যোগ হয়েছে';

  @override
  String expenseDuplicateMessage(String item) {
    return '$item একই টাকায় কয়েক মিনিট আগে যোগ করা হয়েছে।';
  }

  @override
  String get expenseDuplicateSaveAnyway => 'তবুও সংরক্ষণ করুন';

  @override
  String get tripTitle => 'বাজার ট্রিপ';

  @override
  String get tripAddLine => 'পণ্য যোগ করুন';

  @override
  String get tripLineSheetTitle => 'ট্রিপে পণ্য যোগ করুন';

  @override
  String get tripLineSheetSave => 'ট্রিপে যোগ করুন';

  @override
  String tripLinesCount(String count) {
    return 'পণ্য: $count';
  }

  @override
  String get tripEmpty => 'এখনো কোনো পণ্য নেই। প্রথম পণ্যটি যোগ করুন।';

  @override
  String get tripTotalLabel => 'ট্রিপের মোট';

  @override
  String get tripSaveAll => 'সব সংরক্ষণ করুন';

  @override
  String get tripSaved => 'ট্রিপ সংরক্ষণ হয়েছে';

  @override
  String get tripLineRemoved => 'পণ্য সরানো হয়েছে';

  @override
  String get tripLimitReached => 'একটি ট্রিপে সর্বোচ্চ ৪০টি পণ্য থাকতে পারে।';

  @override
  String get expenseListTitle => 'খরচের তালিকা';

  @override
  String get expenseListFilteredTotal => 'এই তালিকার মোট';

  @override
  String get expenseListEmptyTitle => 'এই মাসে কোনো খরচ নেই';

  @override
  String get expenseListEmptyMessage => 'প্রথম খরচ যোগ করলে এখানে দেখা যাবে।';

  @override
  String get expenseListFilteredEmptyTitle =>
      'ফিল্টারের সাথে মেলে এমন কিছু নেই';

  @override
  String get expenseListFilteredEmptyMessage =>
      'সব খরচ দেখতে ফিল্টার মুছে ফেলুন।';

  @override
  String get expenseListLocked => 'এই মাস বন্ধ। এন্ট্রি শুধু দেখা যাবে।';

  @override
  String get expenseListRefresh => 'রিফ্রেশ';

  @override
  String get expenseShowMore => 'আরও দেখান';

  @override
  String get expenseRowDeleted => 'মুছে ফেলা';

  @override
  String get expenseRowTrip => 'ট্রিপ';

  @override
  String get expenseFilterTitle => 'ফিল্টার';

  @override
  String get expenseFilterRange => 'তারিখের সীমা';

  @override
  String expenseFilterRangeActive(String start, String end) {
    return '$start থেকে $end';
  }

  @override
  String get expenseRangeAll => 'পুরো মাস';

  @override
  String get expenseRangeToday => 'আজ';

  @override
  String get expenseRangeYesterday => 'গতকাল';

  @override
  String get expenseRangeLast7 => 'গত ৭ দিন';

  @override
  String get expenseRangeThisWeek => 'এই সপ্তাহ';

  @override
  String get expenseRangeThisMonth => 'এই মাস';

  @override
  String get expenseRangeLastMonth => 'গত মাস';

  @override
  String get expenseRangeThisYear => 'এই বছর';

  @override
  String get expenseRangeCustom => 'তারিখ বেছে নিন';

  @override
  String get expenseFilterCategory => 'ক্যাটেগরি';

  @override
  String get expenseFilterItem => 'পণ্য';

  @override
  String get expenseFilterMember => 'সদস্য';

  @override
  String get expenseFilterFunding => 'টাকার উৎস';

  @override
  String get expenseFilterAny => 'যেকোনো';

  @override
  String get expenseFilterShowDeleted => 'মুছে ফেলা দেখান';

  @override
  String get expenseFilterReset => 'ফিল্টার মুছুন';

  @override
  String get expenseDetailTitle => 'খরচ';

  @override
  String get expenseDetailAddedBy => 'যোগ করেছেন';

  @override
  String get expenseDetailPayment => 'টাকার উৎস ও হিসাব';

  @override
  String get expenseNotYoursMessage =>
      'আপনি শুধু নিজের খরচ পরিবর্তন করতে পারবেন।';

  @override
  String get expenseLedgerFund => 'পরিবারের তহবিল থেকে দেওয়া হয়েছে';

  @override
  String expenseLedgerPersonal(String name) {
    return '$name নিজের টাকায় দিয়েছেন, ফেরত নেই';
  }

  @override
  String expenseLedgerPending(String name, String amount) {
    return '$name দিয়েছেন। $amount ফেরত দেওয়া বাকি।';
  }

  @override
  String expenseLedgerPartial(String name, String settled, String total) {
    return '$name দিয়েছেন। $total এর মধ্যে $settled ফেরত দেওয়া হয়েছে।';
  }

  @override
  String expenseLedgerSettled(String name) {
    return '$name দিয়েছেন। পুরোটা ফেরত দেওয়া হয়েছে।';
  }

  @override
  String get expenseLedgerVoided => 'খরচের সাথে ফেরতও বাতিল হয়েছে।';

  @override
  String get expenseDeleteTitle => 'এই খরচ মুছে ফেলবেন?';

  @override
  String expenseDeleteMessage(String name) {
    return '$name মোট থেকে বাদ যাবে। সাথে সাথে পূর্বাবস্থায় ফেরাতে পারবেন।';
  }

  @override
  String get expenseDeleted => 'খরচ মুছে ফেলা হয়েছে';

  @override
  String get expenseRestore => 'ফিরিয়ে আনুন';

  @override
  String get expenseRestored => 'খরচ ফিরিয়ে আনা হয়েছে';

  @override
  String get expenseHistoryTitle => 'পরিবর্তনের ইতিহাস';

  @override
  String get expenseHistoryEmpty => 'এখনো কোনো পরিবর্তন নেই।';

  @override
  String expenseHistoryEntry(String who, String date) {
    return '$who $date তারিখে পরিবর্তন করেছেন';
  }

  @override
  String expenseHistoryWas(String field, String value) {
    return '$field আগে ছিল: $value';
  }

  @override
  String get catalogTitle => 'পণ্য ও ক্যাটেগরি';

  @override
  String get catalogTabCategories => 'ক্যাটেগরি';

  @override
  String get catalogTabItems => 'পণ্য';

  @override
  String get catalogAdd => 'যোগ করুন';

  @override
  String get catalogAddCategory => 'ক্যাটেগরি যোগ করুন';

  @override
  String get catalogEditCategory => 'ক্যাটেগরি সম্পাদনা';

  @override
  String get catalogAddItem => 'পণ্য যোগ করুন';

  @override
  String get catalogEditItem => 'পণ্য সম্পাদনা';

  @override
  String get catalogCategoryName => 'ক্যাটেগরির নাম';

  @override
  String get catalogNameBn => 'বাংলা নাম';

  @override
  String get catalogNameEn => 'ইংরেজি নাম (ঐচ্ছিক)';

  @override
  String get catalogEmoji => 'ইমোজি (ঐচ্ছিক)';

  @override
  String get catalogColour => 'রং';

  @override
  String catalogColourSemantics(int number) {
    return 'রং $number';
  }

  @override
  String get catalogActive => 'তালিকায় দেখানো হবে';

  @override
  String get catalogActiveHint => 'মুছে না ফেলে লুকাতে বন্ধ করুন।';

  @override
  String get catalogHidden => 'লুকানো';

  @override
  String get catalogReorder => 'সাজাতে টেনে আনুন';

  @override
  String get actionMoveUp => 'উপরে নিন';

  @override
  String get actionMoveDown => 'নিচে নিন';

  @override
  String get catalogReadOnly =>
      'আপনি এটি দেখতে পারবেন, কিন্তু শুধু সংসার ব্যবস্থাপক বা অ্যাডমিন পরিবর্তন করতে পারবেন।';

  @override
  String get catalogCategoriesEmpty => 'এখনো কোনো ক্যাটেগরি নেই';

  @override
  String get catalogItemsEmpty => 'কোনো পণ্য পাওয়া যায়নি';

  @override
  String get catalogSearch => 'পণ্য খুঁজুন';

  @override
  String get catalogAllCategories => 'সব';

  @override
  String get catalogDefaultUnit => 'সাধারণ একক';

  @override
  String get catalogAliases => 'অন্য বানান (খোঁজার জন্য)';

  @override
  String get catalogAliasField => 'একটি বানান যোগ করুন';

  @override
  String get catalogAliasAdd => 'বানান যোগ করুন';

  @override
  String get catalogAliasLimit => 'সর্বোচ্চ ১০টি বানান দেওয়া যাবে।';

  @override
  String get bazarSettingsWeekStart => 'সপ্তাহ শুরু';

  @override
  String get bazarSettingsTarget => 'মাসিক পারিবারিক চাঁদার লক্ষ্য';

  @override
  String get bazarSettingsDueDay => 'চাঁদা দেওয়ার তারিখ (প্রতি মাসে)';

  @override
  String get bazarSettingsAlerts => 'বাজেট সতর্কতা (বাজেটের শতাংশ)';

  @override
  String get bazarSettingsWarnAt => 'সতর্ক করুন';

  @override
  String get bazarSettingsExceededAt => 'সীমা ছাড়ালে';

  @override
  String get bazarSettingsThresholdRange =>
      '১ থেকে ২০০ এর মধ্যে পূর্ণ সংখ্যা দিন।';

  @override
  String get bazarSettingsThresholdOrder =>
      'সতর্কতার শতাংশ সীমা ছাড়ানোর শতাংশের চেয়ে কম হতে হবে।';

  @override
  String get bazarSettingsFundStart => 'তহবিল শুরুর মাস';

  @override
  String get bazarSettingsFundStartUnset =>
      'শুরুর জমা (ওপেনিং ব্যালান্স) লিখলে নিজে থেকে ঠিক হবে।';

  @override
  String get budgetTitle => 'বাজেট';

  @override
  String get budgetNote => 'বাজেট একটি পরিকল্পনা; তহবিলের ব্যালান্সই আসল টাকা।';

  @override
  String get budgetEmptyTitle => 'এই মাসের কোনো বাজেট নেই';

  @override
  String get budgetEmptyMessage =>
      'মাসের পরিকল্পনা করলে খরচের সঙ্গে তুলনা দেখতে পাবেন।';

  @override
  String get budgetEmptyReadOnly =>
      'সংসার ব্যবস্থাপক বা অ্যাডমিন এখনো এই মাসের পরিকল্পনা করেননি।';

  @override
  String get budgetPlanThisMonth => 'এই মাসের পরিকল্পনা করুন';

  @override
  String get budgetCopyLast => 'গত মাসের বাজেট কপি করুন';

  @override
  String get budgetEdit => 'বাজেট সম্পাদনা';

  @override
  String get budgetOverall => 'পুরো মাস';

  @override
  String budgetLeft(String amount) {
    return '$amount বাকি';
  }

  @override
  String budgetOver(String amount) {
    return '$amount বেশি';
  }

  @override
  String get budgetByCategory => 'ক্যাটাগরি অনুযায়ী';

  @override
  String get budgetDryTitle => 'শুকনা বাজারের আনুমানিক হিসাব';

  @override
  String budgetDrySummary(String count, String total) {
    return '$countটি আইটেম, $total';
  }

  @override
  String get budgetDryEmpty => 'এখনো কোনো আইটেম নেই।';

  @override
  String get budgetTotalField => 'মোট বাজেট (খালি রাখলে যোগফল ধরা হবে)';

  @override
  String get budgetDryFromLines => 'নিচের আইটেমগুলোর যোগফল';

  @override
  String get budgetCategoryEstimates => 'ক্যাটাগরি অনুযায়ী আনুমানিক হিসাব';

  @override
  String get budgetLineName => 'আইটেম';

  @override
  String get budgetLineStock => 'মজুদ';

  @override
  String get budgetLineRate => 'দর';

  @override
  String get budgetLineTotal => 'মোট';

  @override
  String get budgetAddLine => 'আইটেম যোগ করুন';

  @override
  String get budgetRemoveLine => 'আইটেম সরান';

  @override
  String get budgetLinesSum => 'আইটেমের মোট';

  @override
  String get budgetSaved => 'বাজেট সংরক্ষিত হয়েছে';

  @override
  String get budgetErrExists => 'এই মাসের বাজেট আগেই আছে।';

  @override
  String get budgetNoLastMonth => 'কপি করার মতো গত মাসের বাজেট নেই।';

  @override
  String get budgetReadOnly =>
      'আপনি বাজেট দেখতে পারবেন, কিন্তু শুধু সংসার ব্যবস্থাপক বা অ্যাডমিন বদলাতে পারবেন।';

  @override
  String get budgetAlertsTitle => 'বাজেট সতর্কতা';

  @override
  String get fundTitle => 'পারিবারিক ফান্ড';

  @override
  String get fundBalanceTitle => 'ফান্ডের ব্যালেন্স';

  @override
  String get fundReceived => 'জমা';

  @override
  String get fundSpent => 'খরচ';

  @override
  String get fundReimbursed => 'ফেরত দেওয়া';

  @override
  String fundClosedOn(String date) {
    return '$date তারিখে বন্ধ হয়েছে';
  }

  @override
  String get fundMonthClosedNotice =>
      'এই মাস বন্ধ, তাই এতে নতুন কিছু যোগ করা যাবে না।';

  @override
  String get fundOverflowWarning =>
      'ফান্ডের তালিকা অনেক বড়; ব্যালেন্স ঠিক রাখতে পুরোনো মাসগুলো বন্ধ করুন।';

  @override
  String get fundDriftWarning =>
      'একটি বন্ধ মাস খাতার সাথে মিলছে না। সেটি আবার খুলে, ঠিক করে আবার বন্ধ করুন।';

  @override
  String fundLedgerIssues(int count) {
    return '$countটি খরচের সাথে ফান্ডের এন্ট্রি মিলছে না।';
  }

  @override
  String get fundMembersTitle => 'সদস্যদের জমা';

  @override
  String get fundNoMembers => 'এখনো কোনো সক্রিয় সদস্য নেই।';

  @override
  String get fundNoPlan => 'এই মাসের কোনো পরিকল্পনা নেই';

  @override
  String get fundPaidUp => 'সম্পূর্ণ জমা হয়েছে';

  @override
  String fundRemainingAmount(String amount) {
    return '$amount বাকি';
  }

  @override
  String fundCredit(String amount) {
    return '$amount বেশি';
  }

  @override
  String fundAwaitingApproval(String amount) {
    return '$amount অনুমোদনের অপেক্ষায়';
  }

  @override
  String get fundHistoryTitle => 'ফান্ডের হিসাব';

  @override
  String get fundHistoryEmpty => 'এই মাসে ফান্ডে এখনো কিছু নেই।';

  @override
  String get fundTxContribution => 'জমা';

  @override
  String get fundTxExpense => 'খরচ';

  @override
  String get fundTxReimbursement => 'ফেরত দেওয়া';

  @override
  String get fundTxOpening => 'প্রারম্ভিক ব্যালেন্স';

  @override
  String get fundTxAdjustment => 'সংশোধন';

  @override
  String get fundSetupTitle => 'ফান্ড শুরু করুন';

  @override
  String get fundSetupMessage =>
      'পরিবারের কাছে এখন যে টাকা আছে লিখে ফান্ড ও তার প্রথম মাস শুরু করুন।';

  @override
  String get fundOpeningBalance => 'প্রারম্ভিক ব্যালেন্স';

  @override
  String get fundSaveOpening => 'প্রারম্ভিক ব্যালেন্স সংরক্ষণ';

  @override
  String get fundAddContribution => 'জমা যোগ করুন';

  @override
  String get fundRequestContribution => 'জমার অনুরোধ করুন';

  @override
  String get fundSaveContribution => 'জমা সংরক্ষণ';

  @override
  String get fundSendRequest => 'অনুরোধ পাঠান';

  @override
  String get fundSendChangeRequest => 'পরিবর্তনের অনুরোধ পাঠান';

  @override
  String get fundEditRequest => 'অনুরোধ সম্পাদনা';

  @override
  String get fundRequestChange => 'পরিবর্তনের অনুরোধ';

  @override
  String get fundContributionLocked => 'মাস বন্ধ';

  @override
  String get fundMemberLabel => 'কে দিয়েছেন';

  @override
  String get fundAmountLabel => 'টাকার পরিমাণ';

  @override
  String get fundMethodLabel => 'কীভাবে দেওয়া হয়েছে';

  @override
  String get fundMethodCash => 'নগদ';

  @override
  String get fundMethodBkash => 'বিকাশ';

  @override
  String get fundMethodNagad => 'নগদ (Nagad)';

  @override
  String get fundMethodBank => 'ব্যাংক';

  @override
  String get fundMethodOther => 'অন্য';

  @override
  String get fundPendingTitle => 'অনুমোদনের অপেক্ষায়';

  @override
  String bazarDashboardPendingApprovals(String count) {
    return '$countটি জমার অনুরোধ অনুমোদনের অপেক্ষায়';
  }

  @override
  String get fundPendingEmpty => 'কোনো অনুরোধ অপেক্ষায় নেই।';

  @override
  String get fundApprove => 'অনুমোদন';

  @override
  String get fundReject => 'প্রত্যাখ্যান';

  @override
  String get fundRejectReasonTitle => 'কেন প্রত্যাখ্যান করছেন?';

  @override
  String get fundRejectReasonHint => 'সদস্য এই কারণটি দেখতে পাবেন।';

  @override
  String fundRejectedReason(String reason) {
    return 'প্রত্যাখ্যাত: $reason';
  }

  @override
  String get fundVoid => 'বাতিল';

  @override
  String get fundGeneratePlan => 'এই মাসের পরিকল্পনা তৈরি করুন';

  @override
  String get fundStatusPending => 'অনুমোদনের অপেক্ষায়';

  @override
  String get fundStatusApproved => 'অনুমোদিত';

  @override
  String get fundStatusRejected => 'প্রত্যাখ্যাত';

  @override
  String get fundStatusVoided => 'বাতিল করা';

  @override
  String get advanceTitle => 'অগ্রিম ফেরত';

  @override
  String advanceOwedTo(String name) {
    return '$name-কে দিতে হবে';
  }

  @override
  String advancePaidTo(String name) {
    return '$name-কে দেওয়া হয়েছে';
  }

  @override
  String advanceOpenCount(int count) {
    return '$countটি অগ্রিম বাকি';
  }

  @override
  String get advanceTotalOwed => 'মোট বাকি';

  @override
  String get advanceShowSettled => 'পরিশোধিত দেখান';

  @override
  String get advanceEmptyTitle => 'ফেরত দেওয়ার কিছু নেই';

  @override
  String get advanceEmptyMessage =>
      'কোনো সদস্য নিজের টাকায় পরিবারের জন্য খরচ করলে, ফেরত দেওয়ার আগ পর্যন্ত তা এখানে দেখা যাবে।';

  @override
  String get advanceSettledOf => 'ফেরত দেওয়া';

  @override
  String get advanceRemaining => 'বাকি';

  @override
  String get advanceSettleTitle => 'ফেরত দিন';

  @override
  String get advanceSettleAction => 'ফেরত দেওয়া লিখুন';

  @override
  String get monthCloseTitle => 'মাস বন্ধ করুন';

  @override
  String get monthCloseManagerOnly =>
      'শুধু সংসার ব্যবস্থাপক বা অ্যাডমিন মাস বন্ধ বা আবার খুলতে পারবেন।';

  @override
  String get monthCloseCurrentHint =>
      'এই মাস বন্ধ করলে এটি পড়ার মতো হয়ে যাবে এবং এর ব্যালেন্স পরের মাসে যাবে।';

  @override
  String get monthCloseWillRecord => 'এই মাস যে ব্যালেন্স নথিভুক্ত করবে';

  @override
  String get monthCloseAdvances => 'বন্ধের পর অগ্রিম বাকি';

  @override
  String get monthCloseExpected => 'পরিকল্পিত জমা';

  @override
  String get monthCloseReceived => 'গৃহীত জমা';

  @override
  String get monthClose => 'মাস বন্ধ করুন';

  @override
  String get monthCloseConfirmTitle => 'এই মাস বন্ধ করবেন?';

  @override
  String get monthCloseConfirmMessage =>
      'মাসটি পড়ার মতো হয়ে যাবে এবং ব্যালেন্স পরের মাসে যাবে। কিছু ভুল থাকলে পরে আবার খুলতে পারবেন।';

  @override
  String get monthClosedDone => 'মাস বন্ধ হয়েছে';

  @override
  String get monthReopen => 'মাস আবার খুলুন';

  @override
  String get monthReopenedDone => 'মাস আবার খোলা হয়েছে';

  @override
  String get monthReopenNoteTitle => 'কেন এই মাস আবার খুলছেন?';

  @override
  String get monthReopenNoteHint => 'একটি ছোট কারণ (অন্তত ৩ অক্ষর)।';

  @override
  String monthClosedChip(String month) {
    return '$month (বন্ধ)';
  }

  @override
  String get reportTitle => 'রিপোর্ট';

  @override
  String get reportShareText => 'রিপোর্টের লেখা শেয়ার করুন';

  @override
  String get reportExport => 'রপ্তানি';

  @override
  String get reportExportCsv => 'CSV ফাইল রপ্তানি করুন';

  @override
  String get reportExportPdf => 'PDF রপ্তানি করুন';

  @override
  String get reportExportFailed =>
      'রিপোর্ট তৈরি বা শেয়ার করা যায়নি। আবার চেষ্টা করুন।';

  @override
  String get reportTabSummary => 'সারসংক্ষেপ';

  @override
  String get reportTabCategories => 'ক্যাটেগরি';

  @override
  String get reportTabItems => 'আইটেম';

  @override
  String get reportTabDays => 'দিন';

  @override
  String get reportTabMembers => 'সদস্য';

  @override
  String get reportTabDry => 'শুকনা বাজার';

  @override
  String get reportTabContributions => 'জমা';

  @override
  String get reportTotal => 'মোট';

  @override
  String get reportAmount => 'টাকা';

  @override
  String get reportAveragePerDay => 'দৈনিক গড়';

  @override
  String get reportRows => 'এন্ট্রি';

  @override
  String get reportRange => 'সময়কাল';

  @override
  String get reportSummaryColumn => 'বিবরণ';

  @override
  String get reportCategoryColumn => 'ক্যাটেগরি';

  @override
  String get reportItemColumn => 'আইটেম';

  @override
  String get reportDayColumn => 'দিন';

  @override
  String get reportMemberColumn => 'সদস্য';

  @override
  String reportPercent(String percent) {
    return '$percent%';
  }

  @override
  String get reportUp => 'বেড়েছে';

  @override
  String get reportDown => 'কমেছে';

  @override
  String get reportFlat => 'অপরিবর্তিত';

  @override
  String get reportPrevious => 'আগে';

  @override
  String reportComparedWith(String period) {
    return '$period-এর তুলনায়';
  }

  @override
  String get reportNoPreviousData => 'আগের কোনো তথ্য নেই';

  @override
  String reportComparisonSemantics(
    String direction,
    String amount,
    String percent,
    String period,
  ) {
    return '$period-এর তুলনায় $direction $amount, $percent';
  }

  @override
  String get reportPrevDay => 'আগের দিন';

  @override
  String get reportPrevWeek => 'গত সপ্তাহ';

  @override
  String get reportPrevMonth => 'গত মাস';

  @override
  String get reportPrevYear => 'গত বছর';

  @override
  String get reportPrevRange => 'আগের সময়কাল';

  @override
  String get reportDryEstimate => 'পরিকল্পিত';

  @override
  String get reportDryActual => 'খরচ';

  @override
  String get reportDryDelta => 'পার্থক্য';

  @override
  String get reportDryPlanned => 'পরিকল্পনা';

  @override
  String get reportDryEmpty =>
      'এই সময়ের জন্য শুকনা বাজারের কোনো পরিকল্পনা নেই।';

  @override
  String get reportOver => 'বেশি';

  @override
  String get reportUnder => 'কম';

  @override
  String get reportExpected => 'পরিকল্পিত';

  @override
  String get reportTruncated =>
      'এই সময়ে অনেকগুলো এন্ট্রি, সব দেখানো যাচ্ছে না। নির্ভুল রিপোর্টের জন্য ছোট সময় বেছে নিন।';

  @override
  String get chartNoData => 'এই সময়ের জন্য দেখানোর মতো কিছু নেই।';

  @override
  String get chartOther => 'অন্যান্য';

  @override
  String chartSlice(String name, String amount, String percent) {
    return '$name $amount, মোটের $percent%';
  }

  @override
  String chartDaySummary(String day, String amount) {
    return 'সবচেয়ে বেশি খরচ $day: $amount';
  }

  @override
  String get choresEmptyTitle => 'কোনো কাজ নেই';

  @override
  String get choresEmptyMessage => 'কাজ যোগ হলে এখানে দেখা যাবে।';

  @override
  String get choresManageAction => 'পরিচালনা';

  @override
  String get choresManageTitle => 'কাজ পরিচালনা';

  @override
  String get choresManageEmptyTitle => 'এখনো কিছু নেই';

  @override
  String get choresManageEmptyMessage => 'কাজ পরিচালনার টুল এখানে দেখা যাবে।';

  @override
  String get choresModuleTitle => 'কাজ';

  @override
  String get permissionManageChoreTemplates => 'কাজ ও রোটেশন পরিচালনা';

  @override
  String get permissionReassignChore => 'কাজ অন্যজনকে দেওয়া';

  @override
  String get permissionRequestSwap => 'কাজ বদলের অনুরোধ';

  @override
  String get permissionCompleteOwnChore => 'নিজের কাজ শেষ করা';

  @override
  String get permissionCommentOnChore => 'কাজে মন্তব্য করা';

  @override
  String get permissionVerifyChore => 'অন্যের কাজ যাচাই করা';

  @override
  String get permissionCompleteChoreForOthers => 'অন্যের কাজ শেষ করে দেওয়া';

  @override
  String get permissionRecordOwnAvailability => 'নিজের অনুপস্থিতি জানানো';

  @override
  String get permissionManageAvailability => 'অনুপস্থিতি পরিচালনা';

  @override
  String get permissionManageChoreOccurrences =>
      'কাজ বাদ দেওয়া, আবার খোলা বা টীকা দেওয়া';

  @override
  String get permissionModerateChoreComments => 'মন্তব্য লুকানো';

  @override
  String get choreStatusSkipped => 'বাদ দেওয়া';

  @override
  String get choreFlagNeedsCover => 'কেউ এখনও নেই';

  @override
  String get choreFlagAwaitingVerification => 'যাচাই বাকি';

  @override
  String get choreFlagNeedsAttention => 'দৃষ্টি দেওয়ার কাজ';

  @override
  String get choreFlagPlanned => 'পরিকল্পিত';

  @override
  String get choreFlagSwapPending => 'বদলের অনুরোধ বাকি';

  @override
  String get reasonSheetHint => 'কেন? (অন্তত ৩টি অক্ষর)';

  @override
  String reasonSheetTooShort(int min) {
    return 'অন্তত $minটি অক্ষর লিখুন।';
  }

  @override
  String get minutesFieldNotSet => 'দিনের শেষে';

  @override
  String get minutesFieldClear => 'সময় মুছে ফেলুন';

  @override
  String colorSwatchLabel(int index, int count) {
    return 'রং $index, মোট $countটি';
  }

  @override
  String avatarStackMore(String first, int rest) {
    return '$first এবং আরও $rest জন';
  }

  @override
  String avatarStackMoreShort(int hidden) {
    return '+$hidden';
  }

  @override
  String stepProgressSemantic(String done, String total) {
    return '$totalটি ধাপের $doneটি শেষ';
  }

  @override
  String get choresFailure_required => 'এটি পূরণ করা জরুরি।';

  @override
  String get choresFailure_slot_name_required =>
      'প্রথমটির পর প্রতিটি সময়ের একটি নাম দিন।';

  @override
  String get choresFailure_too_long => 'লেখাটি খুব বড় হয়ে গেছে।';

  @override
  String get choresFailure_invalid_time => 'সঠিক সময় দিন।';

  @override
  String get choresFailure_invalid_recurrence =>
      'এই পুনরাবৃত্তির নিয়ম ঠিক নেই।';

  @override
  String get choresFailure_no_dates => 'অন্তত একটি দিন বেছে নিন।';

  @override
  String get choresFailure_invalid_range => 'শেষ তারিখ শুরুর আগে হতে পারে না।';

  @override
  String get choresFailure_invalid_date => 'তারিখটি সঠিক নয়।';

  @override
  String get choresFailure_too_many_subtasks =>
      'ধাপ সংখ্যায় বেশি হয়ে গেছে (সর্বোচ্চ ৩০)।';

  @override
  String get choresFailure_too_many_slots =>
      'দিনে বার সংখ্যায় বেশি (সর্বোচ্চ ৬)।';

  @override
  String get choresFailure_duplicate_slot => 'একই নামে দুটি বার আছে।';

  @override
  String get choresFailure_too_many_items => 'পরিমাণটি বেশি হয়ে গেছে।';

  @override
  String get choresFailure_duplicate_id => 'এই নামটি আগেই ব্যবহার করা হয়েছে।';

  @override
  String get choresFailure_reason_required => 'কারণ লিখতে হবে।';

  @override
  String get choresFailure_reason_too_short => 'কারণে অন্তত ৩টি অক্ষর দিন।';

  @override
  String get choresFailure_member_required => 'একজন সদস্য বেছে নিন।';

  @override
  String get choresFailure_invalid_rotation => 'এই রোটেশনটি সঠিক নয়।';

  @override
  String get choresFailure_too_few_members => 'রোটেশনে অন্তত দুই জন সদস্য দিন।';

  @override
  String get choresFailure_invalid_horizon =>
      '১৪ থেকে ৯০ দিনের মধ্যে একটি সীমা বেছে নিন।';

  @override
  String get choresFailure_invalid_week_start =>
      'সপ্তাহের প্রথম দিন সঠিকভাবে বেছে নিন।';

  @override
  String get choresFailure_invalid_minutes =>
      '০০:০০ থেকে ২৩:৫৯ এর মধ্যে সময় দিন।';

  @override
  String get choresFailure_not_assigned_to_you => 'এই কাজটি আপনার নয়।';

  @override
  String get choresFailure_already_completed => 'এই কাজটি আগেই শেষ হয়েছে।';

  @override
  String get choresFailure_not_completed => 'এই কাজটি এখনও শেষ হয়নি।';

  @override
  String get choresFailure_required_subtasks_open =>
      'আগে জরুরি ধাপগুলো শেষ করুন।';

  @override
  String get choresFailure_self_verification =>
      'নিজের কাজ নিজে যাচাই করা যায় না।';

  @override
  String get choresFailure_verification_not_required =>
      'এই কাজে যাচাই দরকার নেই।';

  @override
  String get choresFailure_already_verified => 'এই কাজটি আগেই যাচাই হয়েছে।';

  @override
  String get choresFailure_verified_requires_manager =>
      'যাচাই হওয়া কাজ শুধু পরিচালক আবার খুলতে পারেন।';

  @override
  String get choresFailure_occurrence_started => 'এই কাজটি শুরু হয়ে গেছে।';

  @override
  String get choresFailure_already_skipped =>
      'এই কাজটি আগেই বাদ দেওয়া হয়েছে।';

  @override
  String get choresFailure_not_skipped => 'এই কাজটি বাদ দেওয়া হয়নি।';

  @override
  String get choresFailure_swap_not_pending => 'এই অনুরোধটি আর খোলা নেই।';

  @override
  String get choresFailure_swap_expired => 'এই অনুরোধের সময় শেষ।';

  @override
  String get choresFailure_swaps_disabled => 'এই পরিবারে কাজ বদল বন্ধ আছে।';

  @override
  String get choresFailure_cover_not_needed => 'এই কাজে ইতিমধ্যে কেউ আছেন।';

  @override
  String get choresFailure_availability_overlap =>
      'এই দিনগুলোতে অনুপস্থিতি আগেই জানানো আছে।';

  @override
  String get choresFailure_member_unavailable => 'সদস্যটি ওই দিনে অনুপস্থিত।';

  @override
  String get choresFailure_template_paused => 'এই কাজটি সাময়িকভাবে বন্ধ।';

  @override
  String get choresFailure_rotation_member_inactive =>
      'রোটেশনের একজন সদস্য আর সক্রিয় নন।';

  @override
  String get choresFailure_range_too_large =>
      'একবারে তৈরি করার জন্য সীমাটি বেশি বড়।';

  @override
  String get choresFailure_starter_pack_applied =>
      'এই স্টার্টার প্যাক আগেই যোগ করা হয়েছে।';

  @override
  String get choresFailure_occurrence_deleted => 'এই কাজটি মুছে ফেলা হয়েছে।';

  @override
  String get choresFailure_concurrent_edit =>
      'অন্য কেউ এটি বদলে ফেলেছেন; আবার খুলে চেষ্টা করুন।';

  @override
  String get choresFailure_last_group_in_use =>
      'এই দলটি এখনও কাজে ব্যবহার হচ্ছে।';

  @override
  String get choresFailure_not_a_recipient => 'অনুরোধটি আপনার জন্য নয়।';

  @override
  String get choresFailure_not_found => 'এটি আর নেই।';

  @override
  String get choresFailure_permission_denied => 'এটি করার অনুমতি আপনার নেই।';

  @override
  String get choresFailure_network =>
      'ইন্টারনেট সংযোগ নেই। 연결 দেখে আবার চেষ্টা করুন।';

  @override
  String get choresFailure_unknown => 'কিছু একটা ভুল হয়েছে। আবার চেষ্টা করুন।';

  @override
  String get activityChoresSettingsUpdated => 'কাজের সেটিংস বদলেছেন';

  @override
  String get activityChoresRotationPolicyUpdated => 'অনুপস্থিতির নিয়ম বদলেছেন';

  @override
  String activityChoresTemplateCreated(String name) {
    return '$name কাজটি যোগ করেছেন';
  }

  @override
  String activityChoresTemplateUpdated(String name) {
    return '$name কাজটি বদলেছেন';
  }

  @override
  String activityChoresTemplatePaused(String name) {
    return '$name কাজটি সাময়িকভাবে বন্ধ করেছেন';
  }

  @override
  String activityChoresTemplateResumed(String name) {
    return '$name কাজটি আবার চালু করেছেন';
  }

  @override
  String activityChoresTemplateArchived(String name) {
    return '$name কাজটি আর্কাইভ করেছেন';
  }

  @override
  String activityChoresTemplateDuplicated(String name) {
    return '$name কাজটির কপি করেছেন';
  }

  @override
  String activityChoresStarterPackApplied(String templates, String groups) {
    return 'স্টার্টার কাজগুলো যোগ করেছেন ($templatesটি কাজ, $groupsটি দল)';
  }

  @override
  String activityChoresDutyGroupCreated(String name) {
    return '$name দলটি যোগ করেছেন';
  }

  @override
  String activityChoresDutyGroupUpdated(String name) {
    return '$name দলটি বদলেছেন';
  }

  @override
  String activityChoresRotationChanged(String name) {
    return '$name এর রোটেশন বদলেছেন';
  }

  @override
  String activityChoresOccurrencesGenerated(
    String from,
    String to,
    String count,
  ) {
    return '$from থেকে $to পর্যন্ত কাজ তৈরি হয়েছে ($count)';
  }

  @override
  String activityChoresOccurrencesReplanned(String name, String from) {
    return '$from থেকে $name কাজটি আবার পরিকল্পনা করেছেন';
  }

  @override
  String activityChoresOccurrenceCompleted(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name শেষ করেছেন';
  }

  @override
  String activityChoresOccurrenceUncompleted(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name আবার অসম্পূর্ণ করেছেন';
  }

  @override
  String activityChoresOccurrenceVerified(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name যাচাই করেছেন';
  }

  @override
  String activityChoresOccurrenceReopened(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name আবার খুলেছেন';
  }

  @override
  String activityChoresOccurrenceException(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name এর জন্য ব্যতিক্রম লিখেছেন';
  }

  @override
  String activityChoresOccurrenceSkipped(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name বাদ দিয়েছেন';
  }

  @override
  String activityChoresOccurrenceUnskipped(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name আবার চালু করেছেন';
  }

  @override
  String activityChoresOccurrenceReassigned(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name অন্যকে দিয়েছেন';
  }

  @override
  String activityChoresCommentAdded(String member, String name, String date) {
    return '$member $date-এ $name নিয়ে মন্তব্য করেছেন';
  }

  @override
  String activityChoresCommentHidden(String member, String name, String date) {
    return '$member $date-এ $name এর একটি মন্তব্য লুকিয়েছেন';
  }

  @override
  String activityChoresAvailabilityAdded(
    String member,
    String from,
    String to,
  ) {
    return '$member $from থেকে $to পর্যন্ত অনুপস্থিতি জানিয়েছেন';
  }

  @override
  String activityChoresAvailabilityCancelled(
    String member,
    String from,
    String to,
  ) {
    return '$member $from থেকে $to পর্যন্ত অনুপস্থিতি বাতিল করেছেন';
  }

  @override
  String activityChoresAvailabilityDecided(
    String member,
    String from,
    String to,
  ) {
    return '$member $from থেকে $to পর্যন্ত অনুপস্থিতির সিদ্ধান্ত দিয়েছেন';
  }

  @override
  String activityChoresSwapRequested(
    String member,
    String to,
    String name,
    String date,
  ) {
    return '$member $to-কে $date-এ $name ধরতে অনুরোধ করেছেন';
  }

  @override
  String activityChoresSwapAccepted(String to, String name, String date) {
    return '$to $date-এ $name নিতে রাজি হয়েছেন';
  }

  @override
  String activityChoresSwapDeclined(String to, String name, String date) {
    return '$to $date-এ $name নিতে রাজি হননি';
  }

  @override
  String activityChoresSwapCancelled(String member, String name, String date) {
    return '$member $date-এ $name এর অনুরোধ বাতিল করেছেন';
  }

  @override
  String activityChoresSwapExpired(String name, String date) {
    return '$date-এ $name এর অনুরোধের সময় শেষ হয়েছে';
  }

  @override
  String activityChoresCoverAssigned(String to, String name, String date) {
    return '$to $date-এ $name সামলাবেন';
  }

  @override
  String get occurrenceDetailTitle => 'কাজ';

  @override
  String occurrenceDueToday(String time) {
    return 'আজ, $timeটার মধ্যে';
  }

  @override
  String occurrenceDueDay(String time, String date) {
    return '$date, $timeটার মধ্যে';
  }

  @override
  String get occurrenceDueNoTime => 'দিনের শেষে';

  @override
  String get occurrenceUnassigned => 'এখনো কেউ দায়িত্বে নেই';

  @override
  String occurrenceCoveringFor(String name) {
    return '$name-এর হয়ে করছেন';
  }

  @override
  String get occurrenceStepsTitle => 'ধাপগুলো';

  @override
  String get occurrenceInstructionsTitle => 'কীভাবে করবেন';

  @override
  String occurrenceEstimated(String minutes) {
    return 'প্রায় $minutes মিনিট';
  }

  @override
  String get occurrenceDifficultyEasy => 'সহজ';

  @override
  String get occurrenceDifficultyNormal => 'সাধারণ';

  @override
  String get occurrenceDifficultyHard => 'কঠিন';

  @override
  String get occurrenceTimelineTitle => 'ইতিহাস';

  @override
  String occurrenceEventCompleted(String name) {
    return '$name সম্পন্ন করেছেন';
  }

  @override
  String occurrenceEventUncompleted(String name) {
    return '$name সম্পন্নতা ফিরিয়ে নিয়েছেন';
  }

  @override
  String occurrenceEventVerified(String name) {
    return '$name যাচাই করেছেন';
  }

  @override
  String occurrenceEventReopened(String name, String reason) {
    return '$name আবার খুলেছেন: $reason';
  }

  @override
  String occurrenceEventReassigned(String name, String to, String reason) {
    return '$name $to-কে দিয়েছেন: $reason';
  }

  @override
  String occurrenceEventSkipped(String name, String reason) {
    return '$name বাদ দিয়েছেন: $reason';
  }

  @override
  String occurrenceEventUnskipped(String name) {
    return '$name আবার ফিরিয়ে দিয়েছেন';
  }

  @override
  String occurrenceEventException(String name, String reason) {
    return '$name নোট দিয়ে শেষ করেছেন: $reason';
  }

  @override
  String occurrenceEventSwapped(String name, String to) {
    return '$name $to-এর সাথে বদল করেছেন';
  }

  @override
  String occurrenceEventCovered(String name, String to) {
    return '$name $to-এর কাজ করেছেন';
  }

  @override
  String get occurrenceActionComplete => 'সম্পন্ন করুন';

  @override
  String get occurrenceActionUndo => 'সম্পন্নতা ফিরিয়ে নিন';

  @override
  String get occurrenceActionVerify => 'যাচাই করুন';

  @override
  String get occurrenceActionReopen => 'আবার খুলুন';

  @override
  String get occurrenceActionReassign => 'অন্যকে দিন';

  @override
  String get occurrenceActionSkip => 'বাদ দিন';

  @override
  String get occurrenceActionUnskip => 'ফিরিয়ে দিন';

  @override
  String get occurrenceActionException => 'নোট দিয়ে শেষ করুন';

  @override
  String get occurrenceActionSwap => 'আমি এটা করতে পারব না';

  @override
  String get occurrenceReopenTitle => 'কেন আবার খুলবেন?';

  @override
  String get occurrenceReassignTitle => 'কে করবে?';

  @override
  String get occurrenceReassignReasonTitle => 'কেন অন্যকে দিচ্ছেন?';

  @override
  String get occurrenceSkipTitle => 'কেন বাদ দিচ্ছেন?';

  @override
  String get occurrenceExceptionTitle => 'কী করা যায়নি?';

  @override
  String get occurrenceUndone => 'সম্পন্নতা ফিরিয়ে নেওয়া হয়েছে';

  @override
  String get occurrenceStepReopened => 'হয়ে গেছে: কাজটি আবার খোলা আছে।';

  @override
  String get occurrencePlannedReadOnly =>
      'এটি এখন শুধু পরিকল্পিত; প্রথম পরিবর্তনেই কাজটি যোগ হবে।';

  @override
  String get occurrenceAwaitingVerification =>
      'কাজটি শেষ হয়েছে; যিনি করেননি তিনি যাচাই করবেন।';

  @override
  String get occurrenceReopenStepsTitle => 'কোন ধাপগুলো আবার করতে হবে?';

  @override
  String get occurrenceReopenStepsHint =>
      'যেগুলো বেছে নেবেন সেগুলোর টিক মুছে যাবে।';

  @override
  String get todayTitle => 'আজ';

  @override
  String get todayEmptyTitle => 'আজ কোনো কাজ নেই';

  @override
  String get todayEmptyMessage =>
      'ফাঁকা সময়টা উপভোগ করুন, বা পরে করার জন্য কাজ যোগ করুন।';

  @override
  String get todayAllDoneTitle => 'সব কাজ শেষ';

  @override
  String get todayAllDoneMessage => 'আজকের সব কাজ হয়ে গেছে। ধন্যবাদ!';

  @override
  String get todaySectionOverdue => 'বিলম্বিত';

  @override
  String get todaySectionDone => 'আজ সম্পন্ন';

  @override
  String get todayScopeMine => 'আমার কাজ';

  @override
  String get todayScopeFamily => 'পুরো পরিবার';

  @override
  String todayProgress(String done, String total) {
    return '$total-এর মধ্যে $done সম্পন্ন';
  }

  @override
  String get todayUndo => 'ফিরিয়ে নিন';

  @override
  String get verifyTitle => 'যাচাইয়ের অপেক্ষায়';

  @override
  String get verifyEmptyTitle => 'যাচাই করার কিছু নেই';

  @override
  String get verifyEmptyMessage =>
      'কেউ শেষ করে দিলে যে কাজগুলো যাচাই দরকার, সেগুলো এখানে দেখাবে।';

  @override
  String get verifyApprove => 'ঠিক আছে';

  @override
  String get verifyReopen => 'ফেরত দিন';

  @override
  String get choreDayPartEarlyMorning => 'ভোর';

  @override
  String get choreDayPartMorning => 'সকাল';

  @override
  String get choreDayPartNoon => 'দুপুর';

  @override
  String get choreDayPartAfternoon => 'বিকাল';

  @override
  String get choreDayPartEvening => 'সন্ধ্যা';

  @override
  String get choreDayPartNight => 'রাত';

  @override
  String choreDueTime(String time) {
    return '$timeটার মধ্যে';
  }

  @override
  String choreStepsCount(String done, String total) {
    return '$done/$total';
  }

  @override
  String get choresSettingsTitle => 'কাজের সেটিংস';

  @override
  String get choresSettingsSubtitle => 'পছন্দ, আবর্তন নীতিমালা এবং ক্যাটালগ';

  @override
  String get choresSettingsCalendarTitle => 'ক্যালেন্ডার ও প্রদর্শন';

  @override
  String get choresSettingsGenerationTitle => 'তৈরি ও সময় নির্ধারণ';

  @override
  String get choresSettingsCatalogsTitle => 'ক্যাটালগসমূহ';

  @override
  String get choresSettingsPoliciesTitle => 'নীতিমালা ও নিয়ম';

  @override
  String get choresSettingsHouseRulesTitle => 'পরিবারের নিয়ম';

  @override
  String get choresSettingsDefaultView => 'ডিফল্ট ক্যালেন্ডার ভিউ';

  @override
  String get choresSettingsDefaultScope => 'ডিফল্ট কাজের পরিধি';

  @override
  String get choresSettingsWeekStart => 'সপ্তাহ শুরুর দিন';

  @override
  String get choresSettingsShowProjected => 'সম্ভাব্য কাজ দেখান';

  @override
  String get choresSettingsShowProjectedSubtitle =>
      'ক্যালেন্ডারে আগামী মাসের অনুমানকৃত কাজ দেখাবে';

  @override
  String choresSettingsProjectedMonths(String months) {
    return 'আগামী পূর্বাভাস: $months মাস';
  }

  @override
  String get choresCalendarViewAgenda => 'তালিকা';

  @override
  String get choresCalendarViewMonth => 'মাসিক';

  @override
  String get choresCalendarViewWeek => 'সাপ্তাহিক';

  @override
  String get choresCalendarScopeMine => 'আমার কাজ';

  @override
  String get choresCalendarScopeAll => 'সবার কাজ';

  @override
  String choresSettingsHorizon(String days) {
    return 'কাজ তৈরির সময়কাল: $days দিন';
  }

  @override
  String get choresSettingsHorizonSubtitle =>
      'কত দিন আগে থেকে স্বয়ংক্রিয়ভাবে কাজ তৈরি হবে (১৪-৯০ দিন)';

  @override
  String choresSettingsOverdueGrace(String minutes) {
    return 'গ্রেস পিরিয়ড: $minutes মিনিট';
  }

  @override
  String get choresSettingsOverdueGraceSubtitle =>
      'নির্ধারিত সময়ের কত মিনিট পর কাজ বিলম্বিত ধরা হবে';

  @override
  String get choresSettingsGroupsTitle => 'কাজের গ্রুপসমূহ';

  @override
  String get choresSettingsPresetsTitle => 'সময়ের প্রিসেটসমূহ';

  @override
  String get choresSettingsAbsenceReasonsTitle => 'অনুপস্থিতির কারণসমূহ';

  @override
  String get choresGroupDeactivateWarningTitle => 'গ্রুপটি বন্ধ করবেন?';

  @override
  String get choresGroupDeactivateWarningMessage =>
      'এই গ্রুপের অধীনে কিছু সক্রিয় কাজ রয়েছে। এটি বন্ধ করলে নতুন কাজে এটি বেছে নেওয়া যাবে না, তবে চলমান কাজে কোনো প্রভাব পড়বে না। চালিয়ে যেতে চান?';

  @override
  String get choresGroupColor => 'রং';

  @override
  String get choresGroupIcon => 'আইকন';

  @override
  String get choresGroupAddTitle => 'নতুন গ্রুপ যোগ করুন';

  @override
  String get choresGroupEditTitle => 'গ্রুপ সম্পাদনা';

  @override
  String get choresPresetAddTitle => 'নতুন সময় প্রিসেট যোগ করুন';

  @override
  String get choresPresetEditTitle => 'সময় প্রিসেট সম্পাদনা';

  @override
  String get choresPresetTime => 'দিনের সময়';

  @override
  String get choresSettingsAbsencePolicyTitle => 'অনুপস্থিতির নীতিমালা';

  @override
  String get choresPolicyAskCoverTitle => 'কভারের অনুরোধ (পলিসি A)';

  @override
  String get choresPolicyAskCoverDesc =>
      'অনুপস্থিত সদস্য নিজে পরিবারের অন্য কাউকে তার কাজটি করার অনুরোধ জানান।';

  @override
  String get choresPolicyAskCoverExample =>
      'উদাহরণ: জরুরি কাজে বাইরে থাকলে অন্য সদস্যকে কাজটি করে দিতে অনুরোধ পাঠানো।';

  @override
  String get choresPolicyAutoCoverTitle =>
      'স্বয়ংক্রিয় কভার প্রস্তাব (পলিসি B)';

  @override
  String get choresPolicyAutoCoverDesc =>
      'অ্যাপ উপযুক্ত সদস্যকে স্বয়ংক্রিয়ভাবে বেছে নিয়ে কভারের প্রস্তাব পাঠায় (তিনি গ্রহণ বা প্রত্যাখ্যান করতে পারেন)।';

  @override
  String get choresPolicyAutoCoverExample =>
      'উদাহরণ: ঘূর্ণায়মান তালিকায় পরবর্তী ফ্রি সদস্যের কাছে অনুরোধ যাবে।';

  @override
  String get choresPolicySkipTitle => 'কাজ বাদ দেওয়া (পলিসি C)';

  @override
  String get choresPolicySkipDesc =>
      'অনুপস্থিতির কারণে কাজটি সেদিনের জন্য বাদ দেওয়া হয় এবং স্কোরিংয়ে নিরপেক্ষ থাকে।';

  @override
  String get choresPolicySkipExample =>
      'উদাহরণ: বিশেষ জরুরি না হলে কাজটি পরবর্তী শিডিউল পর্যন্ত অপেক্ষা করবে।';

  @override
  String get choresSettingsSwapsEnabled => 'কাজের অদলবদল (Swap) চালু রাখুন';

  @override
  String get choresSettingsSwapsEnabledSubtitle =>
      'সদস্যরা নিজেদের মধ্যে কাজ অদলবদল করতে পারবেন';

  @override
  String choresSettingsSwapBuffer(String minutes) {
    return 'অদলবদল অনুরোধের মেয়াদ: $minutes মিনিট';
  }

  @override
  String get choresSettingsSwapBufferSubtitle =>
      'অনুরোধ পাঠানোর পর কতক্ষণ পর্যন্ত এটি কার্যকর থাকবে';

  @override
  String get choresSettingsAbsenceApproval => 'অনুপস্থিতিতে অনুমোদনের প্রয়োজন';

  @override
  String get choresSettingsAbsenceApprovalSubtitle =>
      'অনুপস্থিতির অনুরোধ ম্যানেজারের সিদ্ধান্তের জন্য অপেক্ষা করবে';

  @override
  String get choresSettingsWorkloadVisible => 'কাজের বণ্টন সবার জন্য উন্মুক্ত';

  @override
  String get choresSettingsWorkloadVisibleSubtitle =>
      'পরিবারের সব সক্রিয় সদস্য কাজের সমবণ্টনের হিসাব দেখতে পাবেন';

  @override
  String get choresSettingsCompleteForOthers =>
      'অন্যের কাজ সম্পন্ন করার অনুমতি';

  @override
  String get choresSettingsCompleteForOthersSubtitle =>
      'যেকোনো সদস্য অন্যের কাজ সম্পন্ন করতে পারবেন (এডমিন কন্ট্রোল)';

  @override
  String get choresSettingsHouseRulesEditor => 'পরিবারের নিয়মাবলী (মার্কডাউন)';

  @override
  String get choresSettingsHouseRulesPreview => 'প্রিভিউ';

  @override
  String get choresSettingsHouseRulesHelp =>
      'শিরোনাম: # শিরোনাম, বুলেট: - লেখা, গাঢ়: **লেখা**';

  @override
  String get choresSettingsHouseRulesEmpty =>
      'পরিবারের কোনো বিশেষ নিয়ম এখনও যোগ করা হয়নি।';

  @override
  String get choresSettingsSave => 'সেটিংস সংরক্ষণ করুন';

  @override
  String get choresSettingsResetSection => 'সেকশন রিসেট করুন';

  @override
  String get choresSettingsResetConfirmTitle => 'ডিফল্টে ফিরিয়ে নিতে চান?';

  @override
  String get choresSettingsResetConfirmMessage =>
      'এই সেকশনের সব পরিবর্তন ডিফল্ট অবস্থায় ফিরে যাবে। আপনার কোনো কাজ বা টেমপ্লেট মুছে যাবে না।';

  @override
  String get choresSettingsDiscardTitle => 'পরিবর্তন বাতিল করবেন?';

  @override
  String get choresSettingsDiscardMessage =>
      'আপনার কিছু পরিবর্তন সংরক্ষণ করা হয়নি। আপনি কি পাতা ত্যাগ করতে চান?';

  @override
  String get choresSettingsSaved => 'কাজের সেটিংস সংরক্ষিত হয়েছে';

  @override
  String get choresSettingsNotAllowed =>
      'কাজের সেটিংস পরিচালনা করার অনুমতি আপনার নেই।';

  @override
  String get choresSettingsPickIcon => 'আইকন বেছে নিন';

  @override
  String get dutyGroupsTitle => 'ডিউটি গ্রুপ';

  @override
  String get dutyGroupsSubtitle => 'কে ডিউটিতে আছেন আর রোটা কেমন';

  @override
  String get dutyGroupsEmptyTitle => 'এখনও কোনো ডিউটি গ্রুপ নেই';

  @override
  String get dutyGroupsEmptyMessage =>
      'একটি ডিউটি গ্রুপ কয়েকজনের মধ্যে একসেট কাজ পালা করে ভাগ করে দেয়।';

  @override
  String get dutyGroupNew => 'নতুন ডিউটি গ্রুপ';

  @override
  String dutyGroupsTruncated(String count) {
    return 'প্রথম $countটি গ্রুপ দেখানো হচ্ছে।';
  }

  @override
  String dutyGroupOnDutyNow(String name) {
    return 'এখন ডিউটিতে: $name';
  }

  @override
  String get dutyGroupNobodyOnDuty => 'এখনও কেউ ডিউটিতে নেই';

  @override
  String dutyGroupChoreCount(String count) {
    return 'কাজ: $count';
  }

  @override
  String dutyGroupMemberCount(String count) {
    return 'সদস্য: $count';
  }

  @override
  String get dutyGroupSwitchedOff => 'বন্ধ আছে';

  @override
  String get dutyGroupEditTitle => 'ডিউটি গ্রুপ সম্পাদনা';

  @override
  String get dutyGroupNameBn => 'নাম (বাংলা)';

  @override
  String get dutyGroupNameEn => 'নাম (ইংরেজি, ঐচ্ছিক)';

  @override
  String get dutyGroupActive => 'সক্রিয়';

  @override
  String get dutyGroupActiveSubtitle => 'বন্ধ করা গ্রুপ ইতিহাসে থেকে যায়।';

  @override
  String get dutyGroupSave => 'গ্রুপ সংরক্ষণ করুন';

  @override
  String get dutyGroupSaved => 'গ্রুপ সংরক্ষিত হয়েছে';

  @override
  String get dutyGroupReadOnly =>
      'যারা কাজ পরিচালনা করেন শুধু তারাই ডিউটি গ্রুপ বদলাতে পারেন।';

  @override
  String get dutyGroupNotFound => 'এই ডিউটি গ্রুপটি আর নেই।';

  @override
  String get dutyGroupDeactivateTitle => 'এই গ্রুপ বন্ধ করবেন?';

  @override
  String get dutyGroupDeactivateMessage =>
      'কিছু কাজ এখনও এই গ্রুপ ব্যবহার করছে। আপনি না সরানো পর্যন্ত সেগুলো এটিকেই দেখাবে।';

  @override
  String get dutyGroupDeactivateConfirm => 'বন্ধ করুন';

  @override
  String get dutyGroupDelete => 'গ্রুপ মুছুন';

  @override
  String get dutyGroupDeleteTitle => 'এই ডিউটি গ্রুপটি মুছবেন?';

  @override
  String dutyGroupDeleteMessage(String name) {
    return '$name তালিকা থেকে সরে যাবে এবং এর পালা বন্ধ হবে। কাজগুলোর ইতিহাস রয়ে যাবে; আবার পালা চালাতে অন্য গ্রুপে সরিয়ে নিন।';
  }

  @override
  String get dutyGroupDeleted => 'গ্রুপ মুছে ফেলা হয়েছে';

  @override
  String get dutyGroupsShowSwitchedOff => 'বন্ধ করা গ্রুপ দেখান';

  @override
  String dutyGroupsSwitchedOffCount(int count) {
    return '$countটি গ্রুপ বন্ধ আছে';
  }

  @override
  String get dutyGroupsNoneActive => 'সব গ্রুপ বন্ধ করা আছে।';

  @override
  String get dutyRotationMembers => 'পালার ক্রমে সদস্য';

  @override
  String get dutyRotationNeedTwo => 'কমপক্ষে দুইজন সদস্য যোগ করুন।';

  @override
  String get dutyRotationAddMember => 'সদস্য যোগ করুন';

  @override
  String get dutyRotationNoCandidates =>
      'সব সক্রিয় সদস্য ইতিমধ্যে গ্রুপে আছেন।';

  @override
  String dutyRotationRemoveMember(String name) {
    return '$name-কে সরান';
  }

  @override
  String dutyRotationMoveMember(String name) {
    return '$name-কে সরাতে টানুন';
  }

  @override
  String get dutyRotationCycleUnit => 'কতদিন পরপর পালা বদলাবে';

  @override
  String get dutyRotationUnitDay => 'দিন';

  @override
  String get dutyRotationUnitWeek => 'সপ্তাহ';

  @override
  String get dutyRotationUnitMonth => 'মাস';

  @override
  String get dutyRotationUnitOccurrence => 'কাজের দিন';

  @override
  String dutyRotationWeekStart(String day) {
    return 'সপ্তাহ শুরু হয় $day';
  }

  @override
  String get dutyRotationStartsWith => 'প্রথম পালা';

  @override
  String get dutyRotationStartsOn => 'শুরুর তারিখ';

  @override
  String get dutyRotationPickDate => 'তারিখ বেছে নিন';

  @override
  String get dutyRotaTitle => 'পরের পালাগুলো';

  @override
  String get dutyRotaNeedsSchedule =>
      'এই রোটা কাজের দিন গুনে চলে, তাই দেখাতে একটি সময়সূচি লাগবে।';

  @override
  String get dutyRotaNobody => 'এখনও কেউ নেই';

  @override
  String dutyRotaRange(String start, String end) {
    return '$start থেকে $end';
  }

  @override
  String dutyRotaCellLabel(String range, String name) {
    return '$range: $name';
  }

  @override
  String dutyRotaCellLabelCover(String range, String name) {
    return '$range: $name, কভার লাগবে';
  }

  @override
  String get dutyNeedsCover => 'কভার লাগবে';

  @override
  String get dutyMemberGone => 'আর সক্রিয় নন, তাই পালায় কভার লাগবে';

  @override
  String get dutyRosterTitle => 'বর্তমান সদস্য';

  @override
  String get dutyChangeTitle => 'রোটেশন বদলান';

  @override
  String get dutyChangeAdd => 'সদস্য যোগ করুন';

  @override
  String get dutyChangeRemove => 'সদস্য সরান';

  @override
  String get dutyChangeReorder => 'ক্রম বদলান';

  @override
  String get dutyChangeCycle => 'কত পরপর বদলাবে';

  @override
  String get dutyChangeFrom => 'কার্যকর হবে';

  @override
  String dutyChangeNothingBefore(String date) {
    return '$date-এর আগের কিছুই বদলাবে না।';
  }

  @override
  String get dutyChangeApply => 'পরিবর্তন প্রয়োগ করুন';

  @override
  String get dutyChangeAfter => 'পরিবর্তনের পর';

  @override
  String get dutyChangePickMember => 'একজন সদস্য বেছে নিন';

  @override
  String get dutyChangePickCycle => 'দিন, সপ্তাহ বা মাস বেছে নিন';

  @override
  String get dutyPlanFailed =>
      'সংরক্ষিত হয়েছে, কিন্তু তারিখ সাজাতে ব্যর্থ হয়েছে।';

  @override
  String get dutyPlanning => 'তারিখ সাজানো হচ্ছে…';

  @override
  String get dutyChoresTitle => 'এই গ্রুপের কাজ';

  @override
  String get dutyChoresEmpty => 'এই গ্রুপে এখনও কোনো কাজ নেই।';

  @override
  String get dutyChoreAdd => 'এই গ্রুপে কাজ যোগ করুন';

  @override
  String get dutyChoreAddNone => 'সব কাজ ইতিমধ্যে এই গ্রুপে আছে।';

  @override
  String get dutyChoreAddNote =>
      'যে আসন্ন কাজ শুরু হয়নি তা এই রোটায় চলে আসবে।';

  @override
  String get dutyChoreAdded => 'কাজটি গ্রুপে যোগ হয়েছে';

  @override
  String get choresSettingsNeedsInternet =>
      'কাজের সেটিংস সংরক্ষণ করতে ইন্টারনেট সংযোগ লাগবে। আপনার পরিবর্তনগুলো এখানেই থাকছে, অনলাইন হলে আবার চেষ্টা করুন।';

  @override
  String get choresSettingsResetConfirmAction => 'রিসেট করুন';

  @override
  String get choreTemplatesTitle => 'কাজের টেমপ্লেট';

  @override
  String get choreTemplatesSubtitle => 'পরিবারের কাজ তৈরি ও সম্পাদনা করুন';

  @override
  String get choreTemplatesNotAllowed =>
      'শুধু অ্যাডমিন ও মডারেটর কাজ পরিচালনা করতে পারেন।';

  @override
  String get choreListNew => 'নতুন কাজ';

  @override
  String get choreListSearch => 'কাজ খুঁজুন';

  @override
  String get choreListEmptyTitle => 'এখনো কোনো কাজ নেই';

  @override
  String get choreListEmptyMessage =>
      'নতুন কাজ বোতাম দিয়ে প্রথম কাজটি তৈরি করুন।';

  @override
  String get choreListEmptyFiltered => 'কোনো কাজ মেলেনি';

  @override
  String get choreListTruncated =>
      'শুধু প্রথম দিকের কাজগুলো দেখানো হচ্ছে। বাকিগুলো দেখতে অপ্রয়োজনীয় কাজ আর্কাইভ করুন।';

  @override
  String get choreListUpdated => 'হালনাগাদ হয়েছে';

  @override
  String get choreListInvalidSchedule => 'সময়সূচি পড়া যাচ্ছে না';

  @override
  String choreListNext(String date) {
    return 'পরবর্তী: $date';
  }

  @override
  String get choreStatusActive => 'সক্রিয়';

  @override
  String get choreStatusPaused => 'বিরতিতে';

  @override
  String get choreStatusArchived => 'আর্কাইভ করা';

  @override
  String get choreActionPause => 'বিরতি দিন';

  @override
  String get choreActionResume => 'আবার চালু করুন';

  @override
  String get choreActionDuplicate => 'কপি করুন';

  @override
  String get choreActionArchive => 'আর্কাইভ করুন';

  @override
  String get choreArchiveConfirmTitle => 'এই কাজটি আর্কাইভ করবেন?';

  @override
  String get choreArchiveConfirmMessage =>
      'এর নতুন দিন আর তৈরি হবে না। আগের দিন ও ইতিহাস থাকবে।';

  @override
  String get choreDuplicateSuffix => ' (কপি)';

  @override
  String get choreDuplicated => 'কাজটি কপি হয়েছে';

  @override
  String choreSlotCount(String count) {
    return 'দিনে $count বার';
  }

  @override
  String get choreStrategyRotation => 'পালাক্রমে';

  @override
  String get choreStrategyFixed => 'নির্দিষ্ট একজন';

  @override
  String get choreStrategyManual => 'হাতে বণ্টন';

  @override
  String get choreEditorTitleNew => 'নতুন কাজ';

  @override
  String get choreEditorTitleEdit => 'কাজ সম্পাদনা';

  @override
  String get choreEditorNotFound => 'কাজটি পাওয়া যায়নি';

  @override
  String get choreEditorArchivedNote =>
      'এই কাজটি আর্কাইভ করা। দেখা যাবে, কিন্তু বদলানো যাবে না।';

  @override
  String get choreEditorPlanningFailed =>
      'কাজটি সংরক্ষিত হয়েছে, কিন্তু দিন সাজাতে সমস্যা হয়েছে। শেষ করতে আবার চেষ্টা করুন।';

  @override
  String get choreEditorSectionBasics => 'মূল তথ্য';

  @override
  String get choreEditorSectionSchedule => 'সময়সূচি';

  @override
  String get choreEditorSectionWho => 'কে করবে';

  @override
  String get choreEditorSectionSteps => 'ধাপ';

  @override
  String get choreEditorSectionInstructions => 'নির্দেশনা';

  @override
  String get choreEditorSectionOptions => 'অন্যান্য';

  @override
  String choreEditorStepOf(String current, String total) {
    return 'ধাপ $current/$total';
  }

  @override
  String get choreEditorNameBn => 'নাম (বাংলা)';

  @override
  String get choreEditorNameEn => 'নাম (ইংরেজি, ঐচ্ছিক)';

  @override
  String get choreEditorGroup => 'গ্রুপ';

  @override
  String get choreEditorIcon => 'আইকন';

  @override
  String get choreIconRecent => 'পূর্বে ব্যবহৃত আইকন';

  @override
  String get choreIconMore => 'আরও আইকন';

  @override
  String get choreIconPickTitle => 'আইকন বেছে নিন';

  @override
  String get choreIconSearchHint => 'আইকন খুঁজুন';

  @override
  String get choreIconNoMatches => 'এই নামে কোনো আইকন পাওয়া যায়নি।';

  @override
  String get choreEditorColor => 'রঙ';

  @override
  String get choreEditorRepeat => 'পুনরাবৃত্তি';

  @override
  String get choreEditorRepeatChange => 'পুনরাবৃত্তি বদলান';

  @override
  String get choreEditorNextDates => 'পরবর্তী তারিখ';

  @override
  String get choreEditorNoNextDates => 'আর কোনো তারিখ নেই';

  @override
  String choreEditorStartDate(String date) {
    return 'শুরু: $date';
  }

  @override
  String choreEditorEndDate(String date) {
    return 'শেষ: $date';
  }

  @override
  String get choreEditorEndDateNone => 'শেষের তারিখ নেই';

  @override
  String get choreEditorEndDateClear => 'শেষের তারিখ সরান';

  @override
  String get choreEditorTimes => 'দিনের সময়';

  @override
  String get choreEditorEstimatedMinutes => 'আনুমানিক সময় (মিনিট, ঐচ্ছিক)';

  @override
  String get choreEditorDifficulty => 'কাঠিন্য';

  @override
  String get choreDifficultyEasy => 'সহজ';

  @override
  String get choreDifficultyNormal => 'মাঝারি';

  @override
  String get choreDifficultyHard => 'কঠিন';

  @override
  String get choreEditorVerification => 'যাচাই লাগবে';

  @override
  String get choreEditorVerificationHelp =>
      'কাজ শেষ হলে একজন দায়িত্বশীল যাচাই করবেন।';

  @override
  String get choreEditorActive => 'সক্রিয়';

  @override
  String get choreEditorActiveHelp =>
      'বিরতিতে থাকা কাজের নতুন দিন তৈরি হয় না।';

  @override
  String get choreRemindersTitle => 'রিমাইন্ডার';

  @override
  String get choreRemindersStoredNote =>
      'পরে কাজে লাগবে: রিমাইন্ডার পরের আপডেটে পাঠানো হবে।';

  @override
  String get choreReminderAtDue => 'নির্ধারিত সময়ে';

  @override
  String get choreReminderBeforeTitle => 'নির্ধারিত সময়ের আগে';

  @override
  String choreReminderBefore(String minutes) {
    return '$minutes মিনিট আগে';
  }

  @override
  String get choreReminderCustom => 'অন্য মিনিট (১-১৪৪০)';

  @override
  String get choreReminderCustomAdd => 'সময় যোগ করুন';

  @override
  String get choreReminderOverdue => 'দেরি হলে';

  @override
  String get choreReminderOverdueAfter => 'নির্ধারিত সময়ের কত মিনিট পরে';

  @override
  String choreSlotTitle(String number) {
    return 'সময় $number';
  }

  @override
  String get choreSlotLabel => 'এই সময়ের নাম (ঐচ্ছিক)';

  @override
  String get choreSlotLabelRequired => 'এই সময়ের নাম';

  @override
  String get choreSlotLabelNeeded =>
      'সময়গুলো আলাদা বোঝার জন্য এর একটি নাম দিন।';

  @override
  String get choreSlotDueTime => 'শেষ সময়';

  @override
  String get choreSlotAdd => 'আরেকটি সময় যোগ করুন';

  @override
  String get choreSlotRemove => 'এই সময় মুছুন';

  @override
  String choreSlotLimit(String max) {
    return 'দিনে সর্বোচ্চ $maxটি সময়।';
  }

  @override
  String get choreSubtasksEmpty => 'এখনো কোনো ধাপ নেই। ধাপ ঐচ্ছিক।';

  @override
  String get choreSubtaskAdd => 'ধাপ যোগ করুন';

  @override
  String get choreSubtaskTitle => 'ধাপ';

  @override
  String get choreSubtaskRequired => 'আবশ্যক ধাপ';

  @override
  String get choreSubtaskHint => 'ইঙ্গিত (ঐচ্ছিক)';

  @override
  String get choreSubtaskRemove => 'ধাপ মুছুন';

  @override
  String choreSubtaskLimit(String max) {
    return 'সর্বোচ্চ $maxটি ধাপ।';
  }

  @override
  String get choreInstructionsBold => 'গাঢ়';

  @override
  String get choreInstructionsBullet => 'তালিকা';

  @override
  String get choreInstructionsNumbered => 'ক্রমিক তালিকা';

  @override
  String get choreInstructionsHint => 'কাজটি কীভাবে করবেন';

  @override
  String get choreInstructionsEmpty => 'কোনো নির্দেশনা নেই';

  @override
  String get choreAssigneeManualHelp =>
      'কোনো দায়িত্বশীল ঠিক না করা পর্যন্ত কেউ নির্ধারিত থাকবে না।';

  @override
  String get choreAssigneeFixedLabel => 'কে করবে';

  @override
  String get choreAssigneeSourceGroup => 'দায়িত্ব গ্রুপ';

  @override
  String get choreAssigneeSourceOwn => 'নিজস্ব পালা';

  @override
  String get choreAssigneePickGroup => 'একটি দায়িত্ব গ্রুপ বাছুন';

  @override
  String get choreAssigneeNoGroups =>
      'এখনো কোনো দায়িত্ব গ্রুপ নেই। একটি বানান অথবা নিজস্ব পালা ব্যবহার করুন।';

  @override
  String get choreReplanTitle => 'এই পরিবর্তন কোথায় প্রযোজ্য হবে';

  @override
  String get choreReplanMessage =>
      'যে দিনের কাজ শুরু বা শেষ হয়েছে তা কখনো বদলায় না।';

  @override
  String get choreReplanFutureOnly => 'শুধু আগামী দিনগুলো';

  @override
  String get choreReplanIncludeUpcoming =>
      'আগামী দিন এবং এখনো কেউ শুরু করেনি এমন আসন্ন দিনগুলো';

  @override
  String get recurrenceKindOnce => 'একবার';

  @override
  String get recurrenceKindDaily => 'প্রতিদিন';

  @override
  String get recurrenceKindEveryNDays => 'কয়েক দিন পর পর';

  @override
  String get recurrenceKindWeekdays => 'সপ্তাহের নির্দিষ্ট দিন';

  @override
  String get recurrenceKindEveryNWeeks => 'কয়েক সপ্তাহ পর পর';

  @override
  String get recurrenceKindDaysOfMonth => 'মাসের নির্দিষ্ট তারিখ';

  @override
  String get recurrenceKindNthWeekday => 'মাসের একটি সপ্তাহের দিন';

  @override
  String get recurrenceKindLastDay => 'মাসের শেষ দিন';

  @override
  String get recurrencePickerTitle => 'পুনরাবৃত্তি';

  @override
  String get recurrencePickerOnceDate => 'তারিখ';

  @override
  String get recurrencePickerEveryNDays => 'কত দিন পর পর';

  @override
  String get recurrencePickerEveryNWeeks => 'কত সপ্তাহ পর পর';

  @override
  String get recurrencePickerDaysOfMonth => 'মাসের তারিখ';

  @override
  String get recurrencePickerMonthEnd => 'মাস ছোট হলে';

  @override
  String get recurrencePickerMonthEndClamp => 'শেষ দিনে করুন';

  @override
  String get recurrencePickerMonthEndSkip => 'সেই মাস বাদ দিন';

  @override
  String get recurrencePickerNth => 'কোনটি';

  @override
  String get recurrencePickerWeekday => 'সপ্তাহের দিন';

  @override
  String get recurrencePickerWeekdays => 'সপ্তাহের দিনগুলো';

  @override
  String get recurrenceNthFirst => 'প্রথম';

  @override
  String get recurrenceNthSecond => 'দ্বিতীয়';

  @override
  String get recurrenceNthThird => 'তৃতীয়';

  @override
  String get recurrenceNthFourth => 'চতুর্থ';

  @override
  String get recurrenceNthLast => 'শেষ';

  @override
  String get recurrenceListSeparator => ', ';

  @override
  String get recurrenceSummaryOnce => 'একবার';

  @override
  String get recurrenceSummaryDaily => 'প্রতিদিন';

  @override
  String recurrenceSummaryEveryNDays(String n) {
    return 'প্রতি $n দিন পর পর';
  }

  @override
  String recurrenceSummaryWeekdays(String days) {
    return 'প্রতি $days';
  }

  @override
  String recurrenceSummaryEveryNWeeks(String n, String days) {
    return 'প্রতি $n সপ্তাহে $days';
  }

  @override
  String recurrenceSummaryDaysOfMonth(String days) {
    return 'প্রতি মাসের $days তারিখে';
  }

  @override
  String recurrenceSummaryNthWeekday(String nth, String weekday) {
    return 'প্রতি মাসের $nth $weekday';
  }

  @override
  String get recurrenceSummaryLastDay => 'প্রতি মাসের শেষ দিনে';

  @override
  String get starterPackTitle => 'স্টার্টার প্যাক';

  @override
  String get starterPackSubtitle => 'পরিবারের নিয়মিত কাজগুলো একবারে যোগ করুন';

  @override
  String get starterPackManagersOnly =>
      'শুধু হাউসহোল্ড ম্যানেজার স্টার্টার প্যাক যোগ করতে পারেন।';

  @override
  String get starterPackPickBody =>
      'একটি প্যাক বাছুন। প্রতিটি কাজ আপনার পরিবারের নিজের তালিকায় যোগ হবে; কোনো কিছু লক থাকবে না।';

  @override
  String get starterPackFamilyPdfTitle => 'পরিবারের কাজের তালিকা (PDF)';

  @override
  String get starterPackFamilyPdfDescription =>
      'পরিবারের হাতে লেখা তালিকা থেকে দৈনিক, সাপ্তাহিক ও মাসিক কাজ।';

  @override
  String starterPackTemplateCount(String count) {
    return '$countটি কাজ';
  }

  @override
  String starterPackCountHigh(String count) {
    return '$countটি নিশ্চিত';
  }

  @override
  String starterPackCountMedium(String count) {
    return '$countটি মাঝারি নিশ্চিত';
  }

  @override
  String starterPackCountLow(String count) {
    return '$countটি কম নিশ্চিত';
  }

  @override
  String get starterPackPickHint =>
      'নিশ্চিত কাজগুলো আগে থেকেই টিক দেওয়া আছে। বাকিগুলো পরের ধাপে আপনি নিশ্চিত করবেন।';

  @override
  String get starterPackReviewBody =>
      'যা না চান তা টিক তুলে দিন। মাঝারি ও কম নিশ্চিত কাজগুলোর জন্য আপনার নিশ্চিতকরণ দরকার।';

  @override
  String get starterPackConfidenceHigh => 'নিশ্চিত';

  @override
  String get starterPackConfidenceMedium => 'মাঝারি';

  @override
  String get starterPackConfidenceLow => 'কম নিশ্চিত';

  @override
  String get starterPackConfidenceLegend => 'নিশ্চয়তা:';

  @override
  String get starterPackPleaseConfirm => 'নিশ্চিত করুন';

  @override
  String get starterPackDetailsTitle => 'কাজের বিবরণ';

  @override
  String get starterPackDetailsSchedule => 'সময়সূচি';

  @override
  String get starterPackDetailsNotes => 'নোট';

  @override
  String get starterPackDetailsSteps => 'ধাপ';

  @override
  String get starterPackEndOfDay => 'যখনই সুবিধা';

  @override
  String get starterPackHouseRulesTitle => 'ঘরের নিয়ম';

  @override
  String get starterPackHouseRulesHint =>
      'এগুলো কাজের সেটিংসে সংরক্ষিত হবে এবং কাজের ম্যানেজ পেজে দেখা যাবে।';

  @override
  String get starterPackHouseRulesSwitch => 'তালিকার ঘরের নিয়মগুলো যোগ করুন';

  @override
  String get starterPackWhoBody =>
      'দৈনিক কাজ কে কে ভাগ করবেন, প্রথমে কে করবেন এবং কত দিন পর পর পালা বদলাবে তা বাছুন। অথবা এখন কাউকে না দিয়ে পরে ঠিক করুন।';

  @override
  String get starterPackRotationSwitch => 'এই কাজগুলো পালা করে ভাগ করুন';

  @override
  String get starterPackRotationNeedsTwo =>
      'পালার জন্য অন্তত দুইজন সক্রিয় সদস্য দরকার।';

  @override
  String get starterPackNoRotationInfo =>
      'কাজগুলোতে এখনই কাউকে দেওয়া হবে না। পরে একে একে দায়িত্ব দিতে পারবেন।';

  @override
  String get starterPackMembersTitle => 'পালায় যারা থাকবেন';

  @override
  String get starterPackFirstMemberTitle => 'প্রথমে কে';

  @override
  String get starterPackCycleTitle => 'পালা বদলাবে প্রতি';

  @override
  String get starterPackNoMembers =>
      'পালা করার মতো সক্রিয় সদস্য এখন নেই। কাজগুলো পরে দায়িত্ব দিতে পারবেন।';

  @override
  String get starterPackApply => 'এই কাজগুলো যোগ করুন';

  @override
  String get starterPackApplying => 'কাজ যোগ হচ্ছে…';

  @override
  String get starterPackOpenToday => 'আজকের কাজ দেখুন';

  @override
  String get starterPackResultTitle => 'স্টার্টার প্যাক যোগ হয়েছে';

  @override
  String starterPackResultTemplates(String count) {
    return '$countটি কাজ যোগ হয়েছে';
  }

  @override
  String starterPackResultSkipped(String count) {
    return '$countটি আগে থেকেই ছিল';
  }

  @override
  String starterPackResultGroups(String count) {
    return '$countটি কাজের গ্রুপ যোগ হয়েছে';
  }

  @override
  String starterPackResultPresets(String count) {
    return '$countটি সময়ের প্রিসেট যোগ হয়েছে';
  }

  @override
  String starterPackResultDutyGroups(String count) {
    return '$countটি ডিউটি গ্রুপ যোগ হয়েছে';
  }

  @override
  String get starterPackResultRules => 'ঘরের নিয়ম যোগ হয়েছে';

  @override
  String starterPackResultGenerated(String count) {
    return 'আজকের জন্য $countটি কাজ তৈরি হয়েছে';
  }

  @override
  String get starterPackResultGenerationFailed =>
      'কাজগুলো সংরক্ষণ হয়েছে, কিন্তু আজকের কাজ তৈরি করা যায়নি। আজকের পেজ খুলে আবার চেষ্টা করুন।';

  @override
  String starterPackStepOf(String current, String total) {
    return 'ধাপ $current/$total';
  }

  @override
  String get starterPackStepPick => 'প্যাক বাছুন';

  @override
  String get starterPackStepReview => 'পর্যালোচনা';

  @override
  String get starterPackStepWho => 'কে কী করবেন';

  @override
  String get calendarTruncatedBanner =>
      'এই মাসে অনেক কাজ — সব দেখানো যাচ্ছে না';

  @override
  String get calendarTruncatedBannerAction => 'ফিল্টার দেখুন';

  @override
  String get calendarToday => 'আজ';

  @override
  String get calendarPreviousMonth => 'আগের মাস';

  @override
  String get calendarNextMonth => 'পরের মাস';

  @override
  String get calendarPickMonth => 'মাস ও বছর বাছুন';

  @override
  String get calendarPreviousYear => 'আগের বছর';

  @override
  String get calendarNextYear => 'পরের বছর';

  @override
  String get calendarGridLabel => 'মাসের ক্যালেন্ডার';

  @override
  String get calendarFilters => 'ফিল্টার';

  @override
  String calendarFiltersActive(String count) {
    return 'ফিল্টার, $countটি চালু';
  }

  @override
  String get calendarFiltersNone => 'কোনো ফিল্টার চালু নেই।';

  @override
  String get calendarClearFilters => 'ফিল্টার মুছুন';

  @override
  String get calendarDayEmptyTitle => 'এই দিনে কোনো কাজ নেই';

  @override
  String get calendarDayEmptyMessage => 'এই দিনের জন্য কিছু ঠিক করা নেই।';

  @override
  String calendarDayHeader(String date, String count) {
    return '$date · $countটি কাজ';
  }

  @override
  String calendarCellChores(String count) {
    return '$countটি কাজ';
  }

  @override
  String get calendarCellPast => 'আগের তারিখ';

  @override
  String get calendarCellScheduled => 'নির্ধারিত';

  @override
  String calendarCellProgress(String done, String total) {
    return '$totalটির মধ্যে $doneটি সম্পন্ন';
  }

  @override
  String get calendarCellCompleted => 'সব কাজ সম্পন্ন';

  @override
  String calendarDayOpenCount(String count) {
    return 'বাকি: $count';
  }

  @override
  String calendarDaySkippedCount(String count) {
    return 'বাদ: $count';
  }

  @override
  String calendarCellMembers(String names) {
    return 'দায়িত্বে: $names';
  }

  @override
  String get calendarUnknownMember => 'অজানা সদস্য';

  @override
  String calendarCellOverdue(String count) {
    return '$countটি বিলম্বিত';
  }

  @override
  String calendarCellMine(String count) {
    return '$countটি আপনার';
  }

  @override
  String get calendarCellSelected => 'নির্বাচিত';

  @override
  String get calendarOpenToday => 'আজকের কাজ খুলুন';

  @override
  String calendarFreeDays(String count) {
    return '$countটি ফাঁকা দিন';
  }

  @override
  String get calendarLoadEarlier => 'আগের সপ্তাহ দেখুন';

  @override
  String get calendarLoadLater => 'পরের সপ্তাহ দেখুন';

  @override
  String get calendarJumpToToday => 'আজকে ফিরে যান';

  @override
  String get calendarLegend => 'চিহ্নের অর্থ';

  @override
  String get calendarFilterGroups => 'গ্রুপ';

  @override
  String get calendarFilterStatuses => 'অবস্থা';

  @override
  String get calendarFilterMembers => 'সদস্য';

  @override
  String get calendarFilterNeedsAttention => 'শুধু নজর দরকার';

  @override
  String get calendarSearchHint => 'কাজ খুঁজুন';

  @override
  String get calendarAddChore => 'কাজ যোগ করুন';

  @override
  String get calendarMonthNarrow =>
      'মাসের ভিউয়ের জন্য চওড়া পর্দা লাগে, তাই সপ্তাহ দেখানো হচ্ছে।';

  @override
  String get calendarQuickActions => 'কাজের অ্যাকশন';

  @override
  String calendarRemoveFilter(String label) {
    return '$label ফিল্টার সরান';
  }

  @override
  String get calendarPreviousWeek => 'আগের সপ্তাহ';

  @override
  String get calendarNextWeek => 'পরের সপ্তাহ';

  @override
  String get calendarCellNeedsCover => 'কভার লাগবে';

  @override
  String get calendarCellNeedsAttention => 'মনোযোগ দরকার';

  @override
  String get calendarCellAway => 'কেউ অনুপস্থিত';

  @override
  String get calendarCellPlanned => 'পরিকল্পিত';

  @override
  String get calendarDisplayOptions => 'দেখানোর ধরন';

  @override
  String get calendarLegendMarks => 'দিনের ঘরের চিহ্ন';

  @override
  String get calendarLegendAvatarDescription =>
      'সদস্যের আদ্যক্ষর ও রং দিয়ে দায়িত্বে থাকা ব্যক্তিকে চেনা যায়; অ্যাকসেন্ট রিংটি আপনাকে বোঝায়।';

  @override
  String get calendarLegendYouAvatar => 'আপনি';

  @override
  String get calendarLegendDateStates => 'তারিখের পৃষ্ঠ ও সীমানা';

  @override
  String get calendarLegendScheduledSurface =>
      'রঙিন পৃষ্ঠ: এই তারিখে কাজ নির্ধারিত।';

  @override
  String get calendarLegendPastSurface => 'মৃদু পৃষ্ঠ: এটি আগের তারিখ।';

  @override
  String get calendarLegendTodaySurface =>
      'অ্যাকসেন্ট পৃষ্ঠ ও রেখা: আজকের তারিখ।';

  @override
  String get calendarLegendOverdueBorder =>
      'ড্যাশ করা সীমানা: অন্তত একটি কাজের সময় পেরিয়েছে।';

  @override
  String get calendarLegendCompletedBorder =>
      'দুই রেখার সীমানা: বাদ দেওয়া কাজ ছাড়া সব কাজ সম্পন্ন।';

  @override
  String get calendarMonthLandscape =>
      'ফোন আড়াআড়ি ধরলে মাসের ভিউ নেই, তাই সপ্তাহ দেখানো হচ্ছে।';

  @override
  String get calendarUseFamilyDefaults => 'পরিবারের ডিফল্ট ব্যবহার করুন';

  @override
  String get calendarDayPanelLabel => 'নির্বাচিত দিনের কাজ';

  @override
  String get galleryCalendarPolish => 'ক্যালেন্ডারের সদস্য ও তারিখের অবস্থা';

  @override
  String get galleryDashboardCardFrame => 'ড্যাশবোর্ড কার্ড';

  @override
  String get galleryGreetingHeader => 'শুভেচ্ছা';

  @override
  String get galleryBellButton => 'নোটিফিকেশন ঘণ্টা';

  @override
  String get galleryBellOverflow => '৯+';

  @override
  String get galleryAlertStrip => 'সতর্কতার বার';

  @override
  String get galleryActivityTile => 'কার্যকলাপ';

  @override
  String get galleryStatPill => 'পরিসংখ্যান';

  @override
  String get galleryTimeOffsetChips => 'সময়ের ব্যবধান';

  @override
  String get galleryQuietHoursPicker => 'নীরব সময়';

  @override
  String get galleryQuietHoursStart => 'শুরুর সময়';

  @override
  String get galleryQuietHoursEnd => 'শেষের সময়';

  @override
  String get gallerySwitchTileWithReason => 'কারণসহ সুইচ';

  @override
  String get galleryLevelRing => 'স্তরের অগ্রগতি';

  @override
  String get galleryBadgeMedal => 'অর্জনের ব্যাজ';

  @override
  String get galleryEarned => 'অর্জিত';

  @override
  String get galleryUnearned => 'এখনও অর্জিত নয়';

  @override
  String get galleryPlantStageView => 'গাছের স্তর';

  @override
  String get galleryConfettiView => 'উদ্‌যাপনের কনফেটি';

  @override
  String get galleryDiagnosticRow => 'ডায়াগনস্টিক সারি';

  @override
  String get galleryReorderableCardTile => 'সাজানো যায় এমন কার্ড';

  @override
  String get galleryDragLabel => 'টেনে সরান';

  @override
  String get galleryMoveUp => 'উপরে সরান';

  @override
  String get galleryMoveDown => 'নিচে সরান';

  @override
  String get galleryAccessCell => 'ভূমিকার প্রবেশাধিকার';

  @override
  String get galleryAccessHidden => 'লুকানো';

  @override
  String get galleryAccessOn => 'চালু';

  @override
  String get galleryAccessOff => 'বন্ধ';

  @override
  String get galleryAccessRequired => 'আবশ্যক';

  @override
  String get galleryDeliveryModeTile => 'বিজ্ঞপ্তি পাঠানোর ধরন';

  @override
  String get galleryDeliveryNormal => 'সাধারণ';

  @override
  String get galleryDeliveryPush => 'পুশ';

  @override
  String get galleryRecommended => 'প্রস্তাবিত';

  @override
  String get commentsTitle => 'মন্তব্য';

  @override
  String get commentsEmpty =>
      'এখনও কোনো মন্তব্য নেই। কী ঠিক নেই বা কী করা হয়েছে লিখুন।';

  @override
  String get commentsHint => 'মন্তব্য লিখুন';

  @override
  String get commentsSend => 'পাঠান';

  @override
  String get commentsFlagLabel => 'ভুল বা অসম্পূর্ণ হিসেবে চিহ্নিত করুন';

  @override
  String get commentFlagged => 'মনোযোগ দরকার';

  @override
  String get commentResolved => 'সমাধান হয়েছে';

  @override
  String get commentResolve => 'সমাধান হয়েছে বলুন';

  @override
  String get commentReopenWithReason => 'এই কারণে আবার খুলুন';

  @override
  String get commentHide => 'লুকান';

  @override
  String get commentUnhide => 'আবার দেখান';

  @override
  String get commentHiddenByManager => 'ম্যানেজার লুকিয়েছেন';

  @override
  String get commentHideTitle => 'এই মন্তব্য লুকান';

  @override
  String get commentUnhideTitle => 'এই মন্তব্য আবার দেখান';

  @override
  String get commentHideHint => 'কেন? (৩ থেকে ২০০ অক্ষর)';

  @override
  String get commentYou => 'আপনি';

  @override
  String get commentUnreadSemantics => 'নতুন মন্তব্য';

  @override
  String get commentsLimitReached => 'শুধু প্রথম ২০০টি মন্তব্য দেখানো হচ্ছে।';

  @override
  String commentsNew(String count) {
    return '$countটি নতুন';
  }

  @override
  String commentBubbleLabel(String author, String time, String text) {
    return '$author, $time: $text';
  }

  @override
  String activityChoresCommentUnhidden(
    String member,
    String name,
    String date,
  ) {
    return '$member $date-এ $name এর একটি মন্তব্য আবার দেখিয়েছেন';
  }

  @override
  String get inboxTitle => 'বিজ্ঞপ্তি';

  @override
  String get inboxEmpty => 'এখনও কোনো বিজ্ঞপ্তি নেই';

  @override
  String get inboxToday => 'আজ';

  @override
  String get inboxEarlier => 'আগে';

  @override
  String get inboxSparkNote =>
      'অ্যাপ বন্ধ থাকলেও এই ফোনে অনুস্মারক আসবে; অন্যদের কাজ দেওয়া ও বদলির অনুরোধ অ্যাপ খুললে এখানে দেখা যাবে।';

  @override
  String inboxBudgetAlert(String percent) {
    return 'আপনার বাজেট $percent% হয়েছে।';
  }

  @override
  String inboxPendingJoinRequests(String count) {
    return 'পরিবারে যোগ দেওয়ার $countটি অনুরোধ পর্যালোচনা করতে হবে।';
  }

  @override
  String inboxPendingContributionRequests(String count) {
    return 'অবদানের $countটি অনুরোধ পর্যালোচনা করতে হবে।';
  }

  @override
  String get inboxContributionDue =>
      'এই মাসের আপনার অবদান দেওয়ার সময় হয়েছে।';

  @override
  String inboxAwaitingVerification(String count) {
    return 'যাচাইয়ের জন্য $countটি কাজ অপেক্ষা করছে।';
  }

  @override
  String get inboxMarkAllRead => 'সব পড়া হয়েছে';

  @override
  String get inboxUnreadSemantics => 'অপঠিত';

  @override
  String get inboxSomeone => 'কেউ একজন';

  @override
  String get inboxUnknown => 'নতুন বিজ্ঞপ্তি';

  @override
  String get swapSheetTitle => 'কাউকে এই কাজটি নিতে বলুন';

  @override
  String get swapSheetPerson => 'কে নিতে পারবেন?';

  @override
  String get swapSheetNobody => 'ওই দিন কেউ ফাঁকা নেই।';

  @override
  String get swapSheetReasonHint => 'কেন করতে পারছেন না?';

  @override
  String get swapSheetSend => 'অনুরোধ পাঠান';

  @override
  String get swapResponseTitle => 'অনুরোধের উত্তর দিন';

  @override
  String get swapAccept => 'গ্রহণ করুন';

  @override
  String get swapDecline => 'না করুন';

  @override
  String get swapDeclineReasonTitle => 'কেন নয়? (ঐচ্ছিক)';

  @override
  String get swapNeedsInternet => 'এর জন্য ইন্টারনেট দরকার।';

  @override
  String get swapBannerCancel => 'অনুরোধ বাতিল করুন';

  @override
  String get needsCoverTitle => 'যে কাজে বদলি দরকার';

  @override
  String get needsCoverSubtitle => 'যে কাজ এখনও কেউ করতে পারছে না';

  @override
  String get needsCoverEmpty => 'সব কাজেই কেউ আছেন';

  @override
  String get needsCoverNoAccess => 'শুধু ম্যানেজাররা কাজ ঠিক করতে পারেন।';

  @override
  String get needsCoverAssign => 'ঠিক করুন';

  @override
  String get availabilityTitle => 'অনুপস্থিতি';

  @override
  String get availabilitySubtitle => 'যে দিনগুলো আপনি নেই';

  @override
  String get availabilityMine => 'আমার';

  @override
  String get availabilityEveryone => 'সবার';

  @override
  String get availabilityAdd => 'অনুপস্থিতি যোগ করুন';

  @override
  String get availabilityEmpty => 'কোনো অনুপস্থিতি নেই';

  @override
  String get availabilityType => 'ধরন';

  @override
  String get availabilityPickDates => 'তারিখ বেছে নিন';

  @override
  String get availabilityReasonHint => 'কারণ (৩ থেকে ২০০ অক্ষর)';

  @override
  String get availabilitySave => 'সংরক্ষণ করুন';

  @override
  String get availabilityApprove => 'অনুমোদন';

  @override
  String get availabilityReject => 'বাতিল';

  @override
  String get availabilityCancel => 'অনুপস্থিতি বাতিল';

  @override
  String get availabilityStatusPending => 'অনুমোদনের অপেক্ষায়';

  @override
  String get availabilityStatusActive => 'অনুমোদিত';

  @override
  String get availabilityStatusRejected => 'বাতিল হয়েছে';

  @override
  String get availabilityStatusCancelled => 'বাতিল করা হয়েছে';

  @override
  String get availabilityPolicyAsk =>
      'আপনার কাজগুলো বদলি দরকার হিসেবে দেখানো হবে এবং আপনাকে ও ম্যানেজারদের জানানো হবে।';

  @override
  String get availabilityPolicyAuto =>
      'প্রতিটি কাজের জন্য একজন ফাঁকা সদস্যকে বলা হবে। তিনি রাজি না হওয়া পর্যন্ত কিছু বদলাবে না।';

  @override
  String get availabilityPolicySkip => 'একজন ম্যানেজার এই কাজগুলো বাদ দেবেন।';

  @override
  String inboxBellLabel(String count) {
    return 'বিজ্ঞপ্তি, $countটি অপঠিত';
  }

  @override
  String inboxSwapRequest(String name, String chore, String date) {
    return '$name আপনাকে $date-এ $chore নিতে বলছেন';
  }

  @override
  String inboxCoverRequest(String name, String chore, String date) {
    return '$name-এর $date-এ $chore কাজে বদলি দরকার';
  }

  @override
  String inboxSwapAccepted(String name, String chore, String date) {
    return '$name $date-এ $chore নিতে রাজি হয়েছেন';
  }

  @override
  String inboxSwapDeclined(String name, String chore, String date) {
    return '$name $date-এ $chore নিতে রাজি হননি';
  }

  @override
  String inboxSwapCancelled(String name, String chore, String date) {
    return '$name $date-এর $chore অনুরোধ বাতিল করেছেন';
  }

  @override
  String inboxSwapExpired(String chore, String date) {
    return '$date-এর $chore অনুরোধের সময় শেষ হয়ে গেছে';
  }

  @override
  String inboxReassigned(String name, String chore, String date) {
    return '$name $date-এর $chore আপনাকে দিয়েছেন';
  }

  @override
  String get inboxMemberApproved =>
      'পরিবারে যোগ দেওয়ার আপনার অনুরোধ অনুমোদিত হয়েছে।';

  @override
  String inboxNeedsCover(String name, String count, String from, String to) {
    return '$name $from থেকে $to পর্যন্ত নেই: $countটি কাজে বদলি দরকার';
  }

  @override
  String inboxAbsenceApproved(String name) {
    return '$name আপনার অনুপস্থিতি অনুমোদন করেছেন';
  }

  @override
  String inboxAbsenceRejected(String name) {
    return '$name আপনার অনুপস্থিতি বাতিল করেছেন';
  }

  @override
  String inboxChoreReopened(String name, String chore, String date) {
    return '$name $date-এর $chore আবার খুলেছেন';
  }

  @override
  String inboxCommentAttention(String name, String chore, String date) {
    return '$name $date-এর $chore চিহ্নিত করেছেন';
  }

  @override
  String inboxVerificationNeeded(String name, String chore, String date) {
    return '$name $date-এর $chore শেষ করেছেন; যাচাই দরকার';
  }

  @override
  String swapLoadLabel(String count) {
    return 'এই মাসে $countটি কাজ';
  }

  @override
  String swapSheetPreview(String name, String chore, String date) {
    return '$name-কে অনুরোধ: $date-এ $chore নিন';
  }

  @override
  String swapReasonLabel(String reason) {
    return 'কারণ: $reason';
  }

  @override
  String swapBannerSent(String name) {
    return '$name-কে অনুরোধ পাঠানো হয়েছে';
  }

  @override
  String swapBannerForYou(String name) {
    return '$name আপনাকে এই কাজটি নিতে বলেছেন';
  }

  @override
  String availabilityRangeLine(String from, String to) {
    return '$from থেকে $to';
  }

  @override
  String availabilityAffected(String count) {
    return 'এতে $countটি কাজ প্রভাবিত হবে';
  }

  @override
  String get rotaTitle => 'দায়িত্ব বোর্ড';

  @override
  String get rotaSubtitle => 'কে কী করছেন, কতটা';

  @override
  String get rotaWeek => 'সপ্তাহ';

  @override
  String get rotaMonth => 'মাস';

  @override
  String get rotaOnDuty => 'আজ যাঁদের দায়িত্ব';

  @override
  String get rotaOnDutyNobody => 'আজ কারও কাজ নেই।';

  @override
  String get rotaShareTitle => 'কাজের ভাগ';

  @override
  String get rotaMatrixTitle => 'সদস্য ও দিন';

  @override
  String get rotaEmpty => 'এই সময়ে এখনও কোনো কাজ নেই।';

  @override
  String get rotaNoAccess => 'কাজের ভাগ সদস্যদের জন্য লুকানো আছে।';

  @override
  String rotaShareValue(String percent) {
    return 'কাজের $percent%';
  }

  @override
  String rotaMemberStats(String assigned, String done) {
    return '$assignedটি কাজ, $doneটি শেষ';
  }

  @override
  String rotaCovers(String given, String received) {
    return 'বদলি দিয়েছেন $given, বদলি পেয়েছেন $received';
  }

  @override
  String rotaAway(String days) {
    return '$days দিন অনুপস্থিত';
  }

  @override
  String rotaOnDutyCount(String name, String count) {
    return '$name: $countটি কাজ';
  }

  @override
  String rotaCellLabel(String member, String day, String count) {
    return '$member, $day: $countটি কাজ';
  }

  @override
  String choresDashNext(String name) {
    return 'পরের কাজ: $name';
  }

  @override
  String choresDashOverdueCount(String count) {
    return '$countটি বিলম্বিত';
  }

  @override
  String get choresDashOverdueNone => 'কিছুই বিলম্বিত নয়';

  @override
  String choresDashOverdueOldest(String name) {
    return 'সবচেয়ে পুরোনো: $name';
  }

  @override
  String choresDashVerifyCount(String count) {
    return 'যাচাইয়ের অপেক্ষায় $countটি কাজ';
  }

  @override
  String get choresDashWeekTitle => 'এই সপ্তাহ';

  @override
  String choresDashWeekDay(String day, String count) {
    return '$day: $countটি কাজ';
  }

  @override
  String get choresNewAction => 'নতুন কাজ';

  @override
  String get choresMyTodayAction => 'আমার আজ';

  @override
  String get permissionManageEngagement =>
      'ব্যাজ, লেভেল ও বিজ্ঞপ্তির ডিফল্ট পরিচালনা';

  @override
  String get permissionManageDashboardLayout =>
      'কোন ভূমিকা কোন ড্যাশবোর্ড কার্ড দেখবে তা ঠিক করা';

  @override
  String get dashModuleCore => 'পরিবার';

  @override
  String get dashModuleBazar => 'বাজার ও ফান্ড';

  @override
  String get dashModuleChores => 'কাজ';

  @override
  String get dashCardBudgetAlert => 'বাজেট সতর্কতা';

  @override
  String get dashCardApprovals => 'অনুমোদন';

  @override
  String get dashCardChoresToday => 'আজকের কাজ';

  @override
  String get dashCardChoresOverdue => 'বিলম্বিত কাজ';

  @override
  String get dashCardChoresVerify => 'যাচাইয়ের অপেক্ষায়';

  @override
  String get dashCardBazarMonth => 'এই মাসের খরচ';

  @override
  String get dashCardBazarFund => 'পারিবারিক ফান্ড';

  @override
  String get dashCardUpcoming => 'আসছে';

  @override
  String get dashCardChoresWeek => 'এই সপ্তাহ';

  @override
  String get dashCardHubLevel => 'হাব লেভেল';

  @override
  String get dashCardRecentActivity => 'সাম্প্রতিক কার্যক্রম';

  @override
  String get notifChannelChoresDue => 'কাজের সময়';

  @override
  String get notifChannelChoresDueDescription =>
      'নির্ধারিত কাজের সময়ের অনুস্মারক';

  @override
  String get notifChannelChoresOverdue => 'বিলম্বিত কাজ';

  @override
  String get notifChannelChoresOverdueDescription =>
      'অসম্পূর্ণ কাজের অনুস্মারক';

  @override
  String get notifChannelDailySummary => 'সকালের সারাংশ';

  @override
  String get notifChannelDailySummaryDescription =>
      'আজকের কাজের সংক্ষিপ্ত তালিকা';

  @override
  String get notifChannelBazar => 'বাজার ও ফান্ড';

  @override
  String get notifChannelBazarDescription => 'বাজার ও ফান্ডের অনুস্মারক';

  @override
  String get notifChannelFamily => 'পরিবার';

  @override
  String get notifChannelFamilyDescription => 'পরিবার-সম্পর্কিত বিজ্ঞপ্তি';

  @override
  String get notifChannelPushEvents => 'জরুরি বিজ্ঞপ্তি';

  @override
  String get notifChannelPushEventsDescription => 'পরিবারের গুরুত্বপূর্ণ আপডেট';

  @override
  String get levelNameSeed => 'বীজ';

  @override
  String get levelNameSprout => 'অঙ্কুর';

  @override
  String get levelNameSeedling => 'চারা';

  @override
  String get levelNameSapling => 'ছোট গাছ';

  @override
  String get levelNameYoungTree => 'তরুণ গাছ';

  @override
  String get levelNameFlowering => 'ফুলের গাছ';

  @override
  String get levelNameFruiting => 'ফলবতী গাছ';

  @override
  String get levelNameGrandTree => 'মহীরুহ';

  @override
  String get engagementVisibilityPrivate => 'ব্যক্তিগত';

  @override
  String get engagementVisibilityLevels => 'শুধু লেভেল ও ব্যাজ';

  @override
  String get achievementsTitle => 'অর্জন';

  @override
  String get celebrationTitle => 'আজকের কাজ সম্পন্ন!';

  @override
  String get celebrationSemantics => 'আপনার আজকের সব কাজ সম্পন্ন হয়েছে';

  @override
  String celebrationPointsToday(String points) {
    return 'আজ পেয়েছেন $points পয়েন্ট';
  }

  @override
  String get celebrationNewBadges => 'নতুন ব্যাজ';

  @override
  String get celebrationLevelUp => 'আপনি নতুন লেভেলে পৌঁছেছেন!';

  @override
  String achievementLevel(String level) {
    return 'লেভেল $level';
  }

  @override
  String get achievementMaxLevel => 'আপনি সর্বোচ্চ লেভেলে পৌঁছেছেন।';

  @override
  String get achievementsDisabledTitle => 'এই পরিবারে অর্জন বন্ধ আছে।';

  @override
  String achievementPoints(String points) {
    return '$points পয়েন্ট';
  }

  @override
  String achievementProgress(String current, String needed) {
    return 'পরের লেভেলে যেতে $current/$needed পয়েন্ট';
  }

  @override
  String achievementStreak(String days) {
    return 'বর্তমান ধারাবাহিকতা: $days দিন';
  }

  @override
  String achievementBestStreak(String days) {
    return 'সেরা ধারাবাহিকতা: $days দিন';
  }

  @override
  String get achievementCompleted => 'সম্পন্ন কাজ';

  @override
  String get achievementOnTime => 'সময়মতো';

  @override
  String get achievementCovers => 'অন্যের জন্য কভার';

  @override
  String get achievementVerified => 'সমস্যাহীন যাচাই';

  @override
  String get achievementBadges => 'ব্যাজ';

  @override
  String get achievementEarned => 'অর্জিত';

  @override
  String get achievementLocked => 'এখনো অর্জিত হয়নি';

  @override
  String achievementProgressCount(String current, String needed) {
    return '$current/$needed';
  }

  @override
  String achievementProgressPercent(String percent) {
    return '$percent% সময়মতো';
  }

  @override
  String get badgeFreshStart => 'নতুন শুরু';

  @override
  String get badgeFreshStartDescription => 'প্রথম কাজটি সম্পন্ন করুন।';

  @override
  String get badgeConsistent => 'ধারাবাহিক';

  @override
  String badgeConsistentDescription(String days) {
    return '$days দিনের ধারাবাহিকতা বজায় রাখুন।';
  }

  @override
  String get badgeReliable => 'নির্ভরযোগ্য';

  @override
  String badgeReliableDescription(String count) {
    return 'একটি সম্পূর্ণ মাসে $countটি কাজ সময়মতো করুন।';
  }

  @override
  String get badgeHelper => 'সহায়ক';

  @override
  String badgeHelperDescription(String count) {
    return 'অন্যের জন্য $countটি কাজ কভার করুন।';
  }

  @override
  String get badgeDetailChampion => 'যত্নশীল';

  @override
  String badgeDetailChampionDescription(String count) {
    return 'সমস্যা ছাড়া $countটি যাচাইকৃত কাজ করুন।';
  }

  @override
  String get engagementPrivacyTitle => 'পরিবারের সঙ্গে শেয়ার';

  @override
  String get engagementPrivacyExplanation =>
      'পরিবারের সদস্যরা আপনার লেভেল ও ব্যাজ দেখতে পারবেন কি না বেছে নিন।';

  @override
  String get engagementSharingSwitch => 'আমার লেভেল ও ব্যাজ দেখান';

  @override
  String get engagementSharingDescription =>
      'শুধু লেভেল ও অর্জিত ব্যাজ শেয়ার হবে। পয়েন্ট ও ব্যক্তিগত পরিসংখ্যান ব্যক্তিগত থাকবে।';

  @override
  String get engagementFamilyLevelsTitle => 'পরিবারের অর্জন';

  @override
  String get engagementFamilyLevelsEmpty =>
      'এখনো কেউ শেয়ার করার সিদ্ধান্ত নেননি।';

  @override
  String engagementSharedLevelAndBadges(String level, String count) {
    return '$level · $countটি ব্যাজ';
  }

  @override
  String get engagementPointsNeverShared =>
      'পয়েন্ট ও ব্যক্তিগত পরিসংখ্যান কখনো শেয়ার হয় না।';

  @override
  String get engagementHelpersTitle => 'এই মাসের পারিবারিক সহায়তাকারী';

  @override
  String engagementHelpersCount(String count) {
    return '$countটি কভার';
  }

  @override
  String get engagementSettingsNotAllowed =>
      'শুধু পরিবারের ব্যবস্থাপকেরা এই সেটিং বদলাতে পারবেন।';

  @override
  String get engagementSettingsSaved => 'অর্জনের সেটিং সংরক্ষণ করা হয়েছে।';

  @override
  String get engagementSettingsSaveFailed =>
      'অর্জনের সেটিং সংরক্ষণ করা যায়নি।';

  @override
  String get engagementSettingsOffline =>
      'এই সেটিং সংরক্ষণ করতে ইন্টারনেটে যুক্ত হন।';

  @override
  String get engagementSettingsDiscardTitle => 'পরিবর্তন বাতিল করবেন?';

  @override
  String get engagementSettingsDiscardMessage =>
      'সংরক্ষণ না করা অর্জনের পরিবর্তন হারিয়ে যাবে।';

  @override
  String get engagementSettingsGeneral => 'অর্জন';

  @override
  String get engagementSettingsEnabled => 'লেভেল ও ব্যাজ চালু করুন';

  @override
  String get engagementSettingsEnabledDescription =>
      'পরিবারের সদস্যদের অর্জনের অগ্রগতি দেখান।';

  @override
  String get engagementSettingsCelebrations => 'নতুন অর্জন উদযাপন';

  @override
  String get engagementSettingsCelebrationsDescription =>
      'ব্যাজ বা লেভেল অর্জনে ছোট উদযাপন দেখান।';

  @override
  String get engagementSettingsHelpers => 'পারিবারিক সহায়তাকারী দেখান';

  @override
  String get engagementSettingsHelpersDescription =>
      'আজ ও ড্যাশবোর্ডে এই মাসের সহায়তাকারীদের দেখান।';

  @override
  String get engagementSettingsScoring => 'পয়েন্ট';

  @override
  String get engagementSettingsEasyPoints => 'সহজ কাজের পয়েন্ট';

  @override
  String get engagementSettingsNormalPoints => 'সাধারণ কাজের পয়েন্ট';

  @override
  String get engagementSettingsHardPoints => 'কঠিন কাজের পয়েন্ট';

  @override
  String get engagementSettingsLateBonusPercent => 'দেরিতে শেষ করার গুণক (%)';

  @override
  String get engagementSettingsVerifiedBonusPercent =>
      'যাচাইকৃত কাজের গুণক (%)';

  @override
  String get engagementSettingsCoverBonusPercent => 'কভার বোনাসের গুণক (%)';

  @override
  String get engagementSettingsLevels => 'লেভেল';

  @override
  String get engagementSettingsLevelNameBn => 'বাংলা লেভেলের নাম';

  @override
  String get engagementSettingsLevelNameEn => 'ইংরেজি লেভেলের নাম';

  @override
  String get engagementSettingsLevelPoints => 'প্রয়োজনীয় পয়েন্ট';

  @override
  String get engagementSettingsAddLevel => 'লেভেল যোগ করুন';

  @override
  String engagementSettingsNewLevelName(String number) {
    return 'লেভেল $number';
  }

  @override
  String get engagementSettingsRemoveLevel => 'লেভেল সরান';

  @override
  String get engagementSettingsBadgeThresholds => 'ব্যাজের সীমা';

  @override
  String get engagementSettingsConsistentDays =>
      'ধারাবাহিক ব্যাজের দিনের সংখ্যা';

  @override
  String get engagementSettingsReliablePercent =>
      'নির্ভরযোগ্য ব্যাজের সময়মতো কাজের হার';

  @override
  String get engagementSettingsReliableCount => 'প্রয়োজনীয় সম্পন্ন কাজ';

  @override
  String get engagementSettingsHelperCovers => 'সহায়ক ব্যাজের কভার সংখ্যা';

  @override
  String get engagementSettingsDetailCount => 'যত্নশীল ব্যাজের যাচাইকৃত কাজ';

  @override
  String get engagementSettingsResetSection => 'এই অংশের ডিফল্ট ফিরিয়ে আনুন';

  @override
  String get engagementSettingsVisibility => 'পরিবারে দৃশ্যমানতা';

  @override
  String get engagementSettingsPrivate => 'ব্যক্তিগত';

  @override
  String get engagementSettingsLevelsOnly => 'শুধু লেভেল ও ব্যাজ';

  @override
  String get engagementSettingsVisibilityConfirmTitle =>
      'পরিবারের দৃশ্যমানতা বদলাবেন?';

  @override
  String get engagementSettingsVisibilityConfirmMessage =>
      'এর ফলে সদস্যরা শেয়ার করা লেভেল ও ব্যাজ দেখতে পারবেন কি না বদলাবে। পয়েন্ট কখনো শেয়ার হয় না।';

  @override
  String get engagementSettingsVisibilityAdminOnly =>
      'শুধু প্রশাসক পরিবারের দৃশ্যমানতা বদলাতে পারবেন।';

  @override
  String get engagementSettingsInvalidValue =>
      'সঠিক সীমার মধ্যে একটি মান লিখুন।';

  @override
  String get activityNotificationDefaultsUpdated =>
      'বিজ্ঞপ্তির ডিফল্ট বদলানো হয়েছে';

  @override
  String get activityNotificationDeliveryUpdated =>
      'পুশ ও সাধারণ বিজ্ঞপ্তির সেটিং বদলানো হয়েছে';

  @override
  String get activityDashboardPolicyUpdated =>
      'ড্যাশবোর্ডে কে কী দেখবে তা বদলানো হয়েছে';

  @override
  String get activityEngagementSettingsUpdated =>
      'ব্যাজ ও লেভেলের সেটিং বদলানো হয়েছে';

  @override
  String activityEngagementPrivacyUpdated(String visibility) {
    return 'পরিসংখ্যান শেয়ারিং: $visibility';
  }

  @override
  String get notificationFailure_invalid_minutes =>
      '১ থেকে ১৪৪০ এর মধ্যে মিনিট লিখুন।';

  @override
  String get notificationFailure_invalid_offsets =>
      'রিমাইন্ডারের একটি সময় সঠিক নয়।';

  @override
  String get notificationFailure_too_many_offsets =>
      'সর্বোচ্চ ৫টি রিমাইন্ডার দেওয়া যায়।';

  @override
  String get notificationFailure_invalid_quiet_hours => 'নীরব সময় সঠিক নয়।';

  @override
  String get notificationFailure_unknown_notification_type =>
      'এই ধরনের বিজ্ঞপ্তি চেনা যায়নি।';

  @override
  String get notificationFailure_type_not_push_capable =>
      'এই বিজ্ঞপ্তি পুশ হিসেবে পাঠানো যায় না।';

  @override
  String get notificationFailure_permission_denied_by_os =>
      'ফোনের সেটিংসে এই অ্যাপের বিজ্ঞপ্তি বন্ধ আছে।';

  @override
  String get notificationFailure_exact_alarm_denied =>
      'এই ফোনে সঠিক সময়ের রিমাইন্ডার চালু নেই। রিমাইন্ডার কিছুটা দেরিতে আসতে পারে।';

  @override
  String get notificationFailure_scheduler_unavailable =>
      'এই ফোনে রিমাইন্ডার ঠিক করা যায়নি।';

  @override
  String get notificationFailure_push_unavailable =>
      'এখন পুশ বিজ্ঞপ্তি পাওয়া যাচ্ছে না।';

  @override
  String get notificationFailure_inboxItem =>
      'এই বিজ্ঞপ্তিটি খুঁজে পাওয়া যায়নি।';

  @override
  String get notificationSettingsTitle => 'বিজ্ঞপ্তি ও রিমাইন্ডার';

  @override
  String get notificationHelpTitle => 'রিমাইন্ডার কাজ না করলে';

  @override
  String get notificationDeliveryTitle => 'পুশ নাকি সাধারণ বিজ্ঞপ্তি';

  @override
  String get notificationCategoryChores => 'কাজ';

  @override
  String get notificationCategoryBazar => 'বাজার ও অর্থ';

  @override
  String get notificationCategoryFamily => 'পরিবার';

  @override
  String get notificationTemplateHint =>
      'প্রতিটি কাজের রিমাইন্ডার তার টেমপ্লেট থেকেও বদলানো যায়।';

  @override
  String get notificationDefaultOffsets => 'কাজের কতক্ষণ আগে মনে করাবেন';

  @override
  String get notificationCustomOffset => 'মিনিট লিখুন (১–১৪৪০)';

  @override
  String get notificationAddOffset => 'সময় যোগ করুন';

  @override
  String get notificationInvalidOffset =>
      '১–১৪৪০-এর মধ্যে নতুন একটি সময় লিখুন।';

  @override
  String get notificationOverdue => 'কাজ বাকি থাকলে পরে আবার মনে করান';

  @override
  String get notificationQuietHours => 'নীরব সময়';

  @override
  String get notificationQuietStarts => 'শুরু';

  @override
  String get notificationQuietEnds => 'শেষ';

  @override
  String get notificationMorningSummary => 'সকালের কাজের সারাংশ';

  @override
  String notificationSummaryTime(String time) {
    return 'সময়: $time';
  }

  @override
  String get notificationAllEnabled => 'রিমাইন্ডার চালু';

  @override
  String get notificationMasterExplanation =>
      'বন্ধ করলে সব বিভাগের রিমাইন্ডার থামবে; সময়সূচি সংরক্ষিত থাকবে।';

  @override
  String get notificationMasterOffReason =>
      'সব রিমাইন্ডার বন্ধ থাকায় এই বিভাগের রিমাইন্ডারও আসবে না।';

  @override
  String get notificationCategoryOffReason => 'এই বিভাগের রিমাইন্ডার বন্ধ আছে।';

  @override
  String get notificationPushOnPhone => 'এই ফোনে পুশ বিজ্ঞপ্তি নিন';

  @override
  String get notificationSenderSparkHint =>
      'পুশ পাঠানোর ব্যবস্থা নেই (বিনামূল্যের প্ল্যান); এই ফোনের রিমাইন্ডার চলবে।';

  @override
  String get notificationPushAdminOff => 'পরিবারের প্রশাসক পুশ বন্ধ রেখেছেন।';

  @override
  String get notificationPushSavedInactive =>
      'পুশ সেটিং সংরক্ষিত আছে, তবে পুশ চালু না হওয়া পর্যন্ত এটি ব্যবহার হবে না।';

  @override
  String get notificationPushDisabledHere => 'এই ফোনে পুশ বন্ধ আছে।';

  @override
  String get notificationPush => 'পুশ';

  @override
  String get notificationNormal => 'সাধারণ';

  @override
  String get notificationFamilyDefaults => 'পরিবারের ডিফল্ট';

  @override
  String get notificationPermissionChecking => 'বিজ্ঞপ্তির অনুমতি দেখা হচ্ছে…';

  @override
  String get notificationPermissionUnavailable =>
      'ফোনের অনুমতির তথ্য পাওয়া যায়নি।';

  @override
  String get notificationPermissionDenied => 'এই অ্যাপের বিজ্ঞপ্তি বন্ধ আছে।';

  @override
  String get notificationExactAlarmMissing =>
      'সঠিক সময়ের অ্যালার্ম বন্ধ; রিমাইন্ডার দেরিতে আসতে পারে।';

  @override
  String get notificationPermissionGranted => 'চালু';

  @override
  String get notificationAllow => 'অনুমতি দিন';

  @override
  String get notificationAllowExactAlarms => 'অ্যালার্ম চালু করুন';

  @override
  String get notificationSaveFailed =>
      'সংরক্ষণ করা যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।';

  @override
  String get notificationTestTitle => 'ফ্যামিলি হাব পরীক্ষা';

  @override
  String get notificationTestBody => 'এটি আপনার পরীক্ষামূলক রিমাইন্ডার।';

  @override
  String get notificationTestScheduled =>
      '১০ সেকেন্ডের মধ্যে পরীক্ষামূলক বিজ্ঞপ্তি আসবে।';

  @override
  String get notificationTestFailed => 'পরীক্ষামূলক বিজ্ঞপ্তি ঠিক করা যায়নি।';

  @override
  String get notificationTestButton => '১০ সেকেন্ডে পরীক্ষামূলক বিজ্ঞপ্তি';

  @override
  String get notificationUseFamilyDefaults => 'পরিবারের ডিফল্ট ব্যবহার করুন';

  @override
  String get notificationAllowPush => 'পুশ বিজ্ঞপ্তি চালু করুন';

  @override
  String get notificationSenderUnavailable =>
      'পুশ পাঠানোর সার্ভার সেট আপ করা নেই';

  @override
  String get notificationSenderChecking => 'পুশ ব্যবস্থা দেখা হচ্ছে…';

  @override
  String get notificationSenderError => 'পুশ ব্যবস্থার অবস্থা জানা যায়নি';

  @override
  String get notificationSenderReady => 'পুশ পাঠানোর ব্যবস্থা প্রস্তুত';

  @override
  String get notificationSenderLastFailed => 'সর্বশেষ পুশ পাঠানো যায়নি';

  @override
  String notificationRecommended(String recommended) {
    return 'প্রস্তাবিত: $recommended';
  }

  @override
  String get notificationTypeLocked => 'ফোনেই তৈরি হয়; সার্ভার ইভেন্ট নেই।';

  @override
  String get notificationDiscardTitle => 'পরিবর্তন বাতিল করবেন?';

  @override
  String get notificationDiscardMessage =>
      'সংরক্ষণ না করা পরিবর্তন হারিয়ে যাবে।';

  @override
  String get actionDiscard => 'বাতিল করুন';

  @override
  String get notificationDiagnosticsLoading => 'তথ্য লোড হচ্ছে…';

  @override
  String get notificationPushUnavailable => 'পুশ তথ্য পাওয়া যায়নি।';

  @override
  String get notificationPermissionLabel => 'বিজ্ঞপ্তির অনুমতি';

  @override
  String get notificationExactAlarmLabel => 'সঠিক সময়ের অ্যালার্ম';

  @override
  String get notificationBatteryLabel => 'ব্যাটারি সীমাবদ্ধতা';

  @override
  String get notificationOpenSettings => 'ফোনের সেটিংস খুলুন';

  @override
  String get notificationPendingCount => 'অপেক্ষমাণ রিমাইন্ডার';

  @override
  String get notificationNextScheduled => 'পরের নির্ধারিত রিমাইন্ডার';

  @override
  String get notificationAndroidVersion => 'অ্যান্ড্রয়েড সংস্করণ';

  @override
  String get notificationPushToken => 'পুশ টোকেন';

  @override
  String get notificationPushTokenPresent => 'এই ফোনে টোকেন আছে';

  @override
  String get notificationPushTokenMissing => 'এই ফোনে পুশ টোকেন নেই';

  @override
  String get notificationLastPushReceived => 'শেষ পুশ পাওয়ার সময়';

  @override
  String get notificationNever => 'এখনও হয়নি';

  @override
  String get notificationTimezone => 'পরিবারের সময় অঞ্চল';

  @override
  String get notificationLastError => 'সর্বশেষ ত্রুটি';

  @override
  String get notificationReminderError => 'রিমাইন্ডার নির্ধারণের ত্রুটি';

  @override
  String get notificationHelpIntro =>
      'ফোনের অনুমতি ও নির্ধারিত রিমাইন্ডারের অবস্থা দেখুন।';

  @override
  String get notificationChecklistTitle => 'যা পরীক্ষা করবেন';

  @override
  String get notificationChecklistAllow =>
      'Family Hub-এর বিজ্ঞপ্তির অনুমতি দিন।';

  @override
  String get notificationChecklistAlarms => 'সঠিক অ্যালার্মের অনুমতি দিন।';

  @override
  String get notificationChecklistBattery =>
      'Family Hub-এর ব্যাটারি সীমাবদ্ধতা সরান।';

  @override
  String get notificationChecklistForceStop => 'অ্যাপটি জোর করে বন্ধ করবেন না।';

  @override
  String get notificationChecklistOpen =>
      'নতুন তথ্য লোড করতে দিনে অন্তত একবার অ্যাপ খুলুন।';

  @override
  String get notificationNoSenderHonesty =>
      'রিমাইন্ডার এই ফোনে লোড হওয়া তথ্য থেকে নির্ধারিত হয়। অন্য কেউ কাজ দিলে বা অদলবদলের অনুরোধ করলে, অ্যাপ বন্ধ থাকলে তা খুললে দেখা যাবে। বিনামূল্যের প্ল্যানে পুশ পাঠানোর ব্যবস্থা নেই।';

  @override
  String get notificationResetRecommended => 'প্রস্তাবিত সেটিং ফিরিয়ে আনুন';

  @override
  String get notificationTypeSwapRequest => 'কাজ অদলবদলের অনুরোধ';

  @override
  String get notificationTypeSwapResult => 'অদলবদলের সিদ্ধান্ত';

  @override
  String get notificationTypeNeedsCover => 'কাজের জন্য বিকল্প দরকার';

  @override
  String get notificationTypeChoreAssigned => 'নতুন কাজ বরাদ্দ';

  @override
  String get notificationTypeChoreReopened => 'কাজ আবার খোলা হয়েছে';

  @override
  String get notificationTypeCommentAttention => 'মন্তব্যে মনোযোগ দরকার';

  @override
  String get notificationTypeVerificationNeeded => 'কাজ যাচাই দরকার';

  @override
  String get notificationTypeAbsenceDecision => 'অনুপস্থিতির সিদ্ধান্ত';

  @override
  String get notificationTypeMemberJoinRequest => 'পরিবারে যোগদানের অনুরোধ';

  @override
  String get notificationTypeMemberApproved => 'পরিবারে যোগ অনুমোদিত';

  @override
  String get notificationTypeChoreDue => 'কাজের সময়';

  @override
  String get notificationTypeChoreOverdue => 'বিলম্বিত কাজ';

  @override
  String get notificationTypeEveningNudge => 'সন্ধ্যার মনে করানো';

  @override
  String get notificationTypeMorningSummary => 'সকালের সারাংশ';

  @override
  String get notificationTypeContributionDue => 'চাঁদা দেওয়ার সময়';

  @override
  String get notificationTypeMonthEnd => 'মাস শেষের স্মরণ';

  @override
  String get notificationTypeBudgetAlert => 'বাজেট সতর্কতা';

  @override
  String get notificationTypeAchievement => 'অর্জন';

  @override
  String reminderWhyNext(String time) {
    return 'পরের রিমাইন্ডার: $time';
  }

  @override
  String get reminderWhyPush => 'এটি পুশ হিসেবে পাঠানো হবে।';

  @override
  String get reminderWhyGlobalOff => 'সব রিমাইন্ডার বন্ধ আছে।';

  @override
  String get reminderWhyCategoryOff => 'এই বিভাগের রিমাইন্ডার বন্ধ আছে।';

  @override
  String get reminderWhyTemplateOff =>
      'এই কাজের টেমপ্লেটে রিমাইন্ডার বন্ধ আছে।';

  @override
  String get reminderWhyTemplateNoTimings =>
      'এই কাজের জন্য কোনো রিমাইন্ডারের সময় দেওয়া নেই।';

  @override
  String get reminderWhyNotAssigned => 'এই কাজটি আপনাকে বরাদ্দ করা হয়নি।';

  @override
  String get reminderWhyNotOpen => 'কাজটি আর খোলা নেই।';

  @override
  String get reminderWhyUnavailable => 'এই কাজের জন্য বিকল্প দরকার।';

  @override
  String get reminderWhyProjectedPast =>
      'এই পরিকল্পিত কাজের সময় পেরিয়ে গেছে।';

  @override
  String get reminderWhyNoUpcoming => 'এখন থেকে নির্ধারিত কোনো রিমাইন্ডার নেই।';

  @override
  String reminderDueTitle(String choreName) {
    return '$choreName করার সময় হয়েছে';
  }

  @override
  String reminderDueBody(String choreName, String time) {
    return '$choreName কাজটি $time-এর মধ্যে করুন।';
  }

  @override
  String reminderBeforeTitle(String choreName) {
    return '$choreName কাজটির কথা মনে করিয়ে দিচ্ছি';
  }

  @override
  String reminderBeforeBody(String choreName, String minutes, String time) {
    return '$choreName কাজটি $minutes মিনিট পরে, $time-এ করতে হবে।';
  }

  @override
  String reminderOverdueTitle(String choreName) {
    return 'বাকি আছে: $choreName';
  }

  @override
  String reminderOverdueBody(String choreName) {
    return '$choreName কাজটি এখনো সম্পন্ন হয়নি।';
  }

  @override
  String get reminderNudgeTitle => 'আজকের কাজের কথা';

  @override
  String reminderNudgeBody(String count) {
    return 'আজ আরও $countটি কাজ বাকি আছে।';
  }

  @override
  String get reminderSummaryTitle => 'আজকের কাজ';

  @override
  String reminderSummaryBody(String count) {
    return 'আজ আপনার $countটি কাজ আছে।';
  }

  @override
  String get reminderContributionDueTitle => 'মাসিক জমার কথা';

  @override
  String get reminderContributionDueBody =>
      'আপনার এই মাসের জমা দেওয়ার সময় হয়েছে।';

  @override
  String get reminderMonthEndTitle => 'মাস শেষের হিসাব';

  @override
  String get reminderMonthEndBody =>
      'এই মাসের বাজারের হিসাব বন্ধ করার সময় হয়েছে।';

  @override
  String get engagementFailure_invalid_levels => 'লেভেলের তালিকা সঠিক নয়।';

  @override
  String get engagementFailure_levels_not_ascending =>
      'প্রতিটি লেভেলে আগেরটির চেয়ে বেশি পয়েন্ট লাগবে।';

  @override
  String get engagementFailure_too_many_levels =>
      'সর্বোচ্চ ১২টি লেভেল রাখা যায়।';

  @override
  String get engagementFailure_invalid_threshold =>
      'ব্যাজের একটি সীমা সঠিক নয়।';

  @override
  String get engagementFailure_invalid_points => 'পয়েন্টের একটি মান সঠিক নয়।';

  @override
  String get engagementFailure_invalid_permille => 'শতাংশের একটি মান সঠিক নয়।';

  @override
  String get engagementFailure_invalid_visibility =>
      'শেয়ারিংয়ের এই পছন্দটি সঠিক নয়।';

  @override
  String get engagementFailure_stats_not_owner =>
      'এই পরিসংখ্যান শুধু এর মালিকই বদলাতে পারেন।';

  @override
  String get engagementFailure_stats_regression =>
      'এই পরিসংখ্যান আপডেট করা যায়নি।';

  @override
  String get engagementFailure_engagement_disabled =>
      'এই পরিবারে ব্যাজ ও লেভেল বন্ধ আছে।';

  @override
  String get engagementFailure_already_celebrated =>
      'আজকের উদযাপন আগেই দেখানো হয়েছে।';

  @override
  String get engagementFailure_sharing_not_allowed =>
      'এই পরিবারে শেয়ারিং চালু নেই।';

  @override
  String get engagementFailure_memberStats =>
      'এই পরিসংখ্যান খুঁজে পাওয়া যায়নি।';

  @override
  String get dashboardFailure_unknown_card =>
      'এই ড্যাশবোর্ড কার্ডটি চেনা যায়নি।';

  @override
  String get dashboardFailure_invalid_access =>
      'প্রবেশাধিকারের এই পছন্দটি সঠিক নয়।';

  @override
  String get greetingMorning => 'সুপ্রভাত';

  @override
  String get greetingAfternoon => 'শুভ অপরাহ্ণ';

  @override
  String get greetingEvening => 'শুভ সন্ধ্যা';

  @override
  String get greetingDefaultName => 'আপনি';

  @override
  String get dashboardBellOverflow => '৯+';

  @override
  String get dashboardMenu => 'ড্যাশবোর্ডের বিকল্প';

  @override
  String get dashboardCustomize => 'ড্যাশবোর্ড সাজান';

  @override
  String get dashboardAccess => 'ভূমিকা অনুযায়ী ড্যাশবোর্ড';

  @override
  String get dashboardEmptyTitle => 'আপনার ড্যাশবোর্ড খালি';

  @override
  String get dashboardEmptyMessage =>
      'কোন কার্ড দেখাবেন বেছে নিয়ে নিজের মতো সাজিয়ে নিন।';

  @override
  String get dashboardUpcomingTitle => 'আসন্ন কাজ';

  @override
  String get dashboardUpcomingEmpty => 'আপনার জন্য সামনে কোনো কাজ নেই।';

  @override
  String get dashboardApprovalsTitle => 'আপনার মনোযোগ প্রয়োজন';

  @override
  String dashboardPendingJoinRequests(String count) {
    return 'যোগদানের অনুরোধ: $count';
  }

  @override
  String dashboardPendingContributions(String count) {
    return 'চাঁদার অনুরোধ: $count';
  }

  @override
  String get dashboardRecentActivityTitle => 'সাম্প্রতিক কার্যকলাপ';

  @override
  String get dashboardHubLevelTitle => 'হাবের স্তর';

  @override
  String get dashboardHubLevelComingSoon => 'পরিবারের অগ্রগতি এখানে দেখা যাবে।';

  @override
  String get dashboardAskAiTitle => 'ফ্যামিলি হাবকে জিজ্ঞেস করুন';

  @override
  String get dashboardAskAiMessage => 'পরিবার সম্পর্কে কোনো প্রশ্ন করুন।';

  @override
  String get dashboardCardBudgetAlert => 'বাজেট সতর্কতা';

  @override
  String get dashboardCardApprovals => 'অনুমোদনের অপেক্ষায়';

  @override
  String get dashboardCardChoresToday => 'আজকের কাজ';

  @override
  String get dashboardCardChoresOverdue => 'বকেয়া কাজ';

  @override
  String get dashboardCardChoresVerify => 'যাচাইয়ের অপেক্ষায়';

  @override
  String get dashboardCardBazarMonth => 'মাসিক খরচ';

  @override
  String get dashboardCardBazarFund => 'তহবিলের স্থিতি';

  @override
  String get dashboardCardUpcoming => 'আসন্ন কাজ';

  @override
  String get dashboardCardChoresWeek => 'এই সপ্তাহ';

  @override
  String get dashboardCardHubLevel => 'হাবের স্তর';

  @override
  String get dashboardCardRecentActivity => 'সাম্প্রতিক কার্যকলাপ';

  @override
  String get dashboardPersonalLayoutNote =>
      'এই ড্যাশবোর্ডের বিন্যাস শুধু আপনি দেখতে পাবেন।';

  @override
  String get dashboardHiddenCards => 'লুকানো কার্ড';

  @override
  String get dashboardAddBack => 'আবার যোগ করুন';

  @override
  String get dashboardMoveUp => 'উপরে সরান';

  @override
  String get dashboardMoveDown => 'নিচে সরান';

  @override
  String dashboardDragCard(Object card) {
    return '$card সাজান';
  }

  @override
  String get dashboardRequired => 'অবশ্যক';

  @override
  String get dashboardReset => 'ডিফল্টে ফিরুন';

  @override
  String get dashboardResetTitle => 'ড্যাশবোর্ডের বিন্যাস ফিরিয়ে দেবেন?';

  @override
  String get dashboardResetMessage =>
      'কার্ডের ক্রম ও দৃশ্যমানতা ডিফল্টে ফিরে যাবে।';

  @override
  String get dashboardPrefsSyncPending =>
      'বিন্যাস এই ডিভাইসে সংরক্ষিত হয়েছে; অনলাইনে এলে সিঙ্ক হবে।';

  @override
  String get dashboardAccessInfo =>
      'সংসার ব্যবস্থাপক ও সদস্যরা কোন ড্যাশবোর্ড কার্ড দেখবেন তা বেছে নিন। অ্যাডমিন সবসময় সব উপলভ্য কার্ড দেখবেন।';

  @override
  String get dashboardAdminAlways => 'অ্যাডমিন: সবসময় দৃশ্যমান';

  @override
  String get dashboardPreviewTitle => 'যেভাবে দেখুন';

  @override
  String get dashboardPreviewEmpty => 'এই পূর্বরূপে কোনো কার্ড দৃশ্যমান নয়।';

  @override
  String get dashboardAccessHidden => 'লুকানো';

  @override
  String get dashboardAccessVisible => 'দৃশ্যমান';

  @override
  String get dashboardAccessOff => 'ডিফল্টে বন্ধ';

  @override
  String get dashboardCardPermissionMissing =>
      'এই ভূমিকা কার্ডটির ফিচার ব্যবহার করতে পারে না।';

  @override
  String get dashboardAccessOffline =>
      'ড্যাশবোর্ডে প্রবেশাধিকার সংরক্ষণ করতে ইন্টারনেটে যুক্ত হন।';

  @override
  String get dashboardSaving => 'সংরক্ষণ হচ্ছে…';

  @override
  String get dashboardAccessDenied =>
      'ড্যাশবোর্ডে প্রবেশাধিকার পরিবর্তনের অনুমতি আপনার নেই।';

  @override
  String get dashboardResetRecommended => 'প্রস্তাবিত বিন্যাসে ফিরুন';

  @override
  String get dashboardResetRecommendedTitle =>
      'ড্যাশবোর্ডের প্রবেশাধিকার ফিরিয়ে দেবেন?';

  @override
  String get dashboardResetRecommendedMessage =>
      'সব ভূমিকার প্রবেশাধিকার প্রস্তাবিত ডিফল্টে ফিরে যাবে।';

  @override
  String get dashboardDiscardTitle => 'পরিবর্তন বাতিল করবেন?';

  @override
  String get dashboardDiscardMessage =>
      'সংরক্ষণ না করা ড্যাশবোর্ড প্রবেশাধিকারের পরিবর্তন হারিয়ে যাবে।';

  @override
  String get dashboardDiscard => 'বাতিল করুন';

  @override
  String get activityTitle => 'কার্যকলাপ';

  @override
  String get activityEmpty => 'এখনও কোনো কার্যকলাপ নেই।';

  @override
  String get activityNoMatches => 'এই ফিল্টারে কোনো কার্যকলাপ নেই।';

  @override
  String get activityLoadError =>
      'কার্যকলাপ আনা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।';

  @override
  String get activityLoadMore => 'আরও দেখুন';

  @override
  String get activityModuleFilter => 'বিভাগ';

  @override
  String get activityModuleAll => 'সব বিভাগ';

  @override
  String get activityModuleBazar => 'বাজার ও অর্থ';

  @override
  String get activityModuleChores => 'ঘরের কাজ';

  @override
  String get activityModuleFamily => 'পরিবার';

  @override
  String get activityModuleEngagement => 'ব্যাজ ও স্তর';

  @override
  String get activityMemberFilter => 'সদস্য';

  @override
  String get activityMemberAll => 'সব সদস্য';

  @override
  String get activityUnknownActor => 'অজানা সদস্য';
}
